package org.ws.util;

import junit.framework.TestCase;

public class MD5CodeTest extends TestCase {
	public void test(){
		MD5Code md5 = new MD5Code() ;
		System.out.println(md5.getMD5ofStr("40109135"));
	}
}
