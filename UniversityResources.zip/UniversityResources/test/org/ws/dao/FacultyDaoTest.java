package org.ws.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.WordSimilarity;
import org.ws.vo.person.Faculty;

import junit.framework.TestCase;

public class FacultyDaoTest extends TestCase {
	public void testGetByConditionRange(){
		List<Faculty> all = null ;
		try {
			all = DaoFactory.getFacultyDaoInstance().getByConditionRange("wages",2000,4000,3,1,10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Faculty> iter = all.iterator() ;
		while(iter.hasNext()){
			Faculty faculty = iter.next() ;
			System.out.println(faculty.getName()+"\t"+faculty.getNation()+faculty.getTelephone()) ;
		}
	}
	
	public void testGetByKeyword(){
		List<Faculty> all = null ;
		try {
			all = DaoFactory.getFacultyDaoInstance().getByKeyword("��",1,10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Faculty> iter = all.iterator() ;
		while(iter.hasNext()){
			Faculty faculty = iter.next() ;
			System.out.println(faculty.getName()+"\t"+faculty.getNation()+"\t"+faculty.getWorkplace()) ;
		}
	}
	
	public void testGetByKeywordMap(){
		List<Faculty> all = null ;
		Map<String,Double> map = WordSimilarity.getWordsBySimilarity("�߼�����",MyTools.SIMILARITY) ;
		try {
			all = DaoFactory.getFacultyDaoInstance().getByKeywordMap(map,2,1) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Faculty> iter = all.iterator() ;
		while(iter.hasNext()){
			Faculty faculty = iter.next() ;
			System.out.println(faculty.getName()+"\t"+faculty.getNation()+"\t"+faculty.getWorkplace()) ;
		}
	}
	
	
	public void testGetByBSD(){
		List<Faculty> all = null ;
		try {
			all = DaoFactory.getFacultyDaoInstance().getByBSD("workload",10, 20,60,3, "wages", 2000,10000,20000, 1, 1, 10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Faculty> iter = all.iterator() ;
		while(iter.hasNext()){
			Faculty faculty = iter.next() ;
			System.out.println(faculty.getName()+"\t"+faculty.getWorkload()+"\t"+faculty.getWages()) ;
		}
	}
}
