package org.ws.dao;

import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.vo.car.Car;

public class CarDaoTest extends TestCase{
	
	public void testGetByBSD(){
		List<Car> all = null ;
		try {
			all = DaoFactory.getCarDaoInstance().getByBSD(85500, 114500, "ѩ����", 1, 10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Car> iter = all.iterator() ;
		while(iter.hasNext()){
			Car car = iter.next() ;
			System.out.println(car.getBrand()+"\t"+car.getPrice()+"\t"+car.getuC()+"\t"+car.getuP()+"\t"+car.getrCP()) ;
		}
	}
}
