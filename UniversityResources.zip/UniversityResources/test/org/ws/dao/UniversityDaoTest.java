package org.ws.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.WordSimilarity;
import org.ws.vo.organization.University;

public class UniversityDaoTest extends TestCase {
	public void testGetByKeywordMap(){
		Map<String,Double> map = WordSimilarity.getWordsBySimilarity("����",MyTools.SIMILARITY) ;
		List<University> all = null ;
		try {
			all = DaoFactory.getUniversityDaoInstance().getByKeywordMap(map,1,10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<University> iter = all.iterator() ;
		while(iter.hasNext()){
			University uni = iter.next() ;
			System.out.println(uni.getIntroduction()) ;
		}
	}
	public void testGetById(){
		University uni = null ;
		try {
			uni = DaoFactory.getUniversityDaoInstance().getById("12544") ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(uni.getIntroduction());
	}
	
	public void testGetByMajor(){
		List<University> all = null ;
		try {
			all = DaoFactory.getUniversityDaoInstance().getByMajor("computer", 1, 10);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<University> iter = all.iterator() ;
		while(iter.hasNext()){
			University uni = iter.next() ;
			System.out.println(uni.getName()+"           "+"         "+uni.getMarjors().iterator().next().getName()+"         "+uni.getArea().getName());
		}
	}
	
	public void testGetByArea(){
		List<University> all = null ;
		try {
			all = DaoFactory.getUniversityDaoInstance().getByArea("Northwest", 1, 10);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<University> iter = all.iterator() ;
		while(iter.hasNext()){
			University uni = iter.next() ;
			System.out.println(uni.getName()+"           "+"         "+uni.getMarjors().iterator().next().getName()+"         "+uni.getArea().getName());
		}
	}
}
