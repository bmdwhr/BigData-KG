package org.ws.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.WordSimilarity;
import org.ws.vo.work.Research;

public class ResearchDaoTest extends TestCase {
	
	public void testGetByKeyword(){
		List<Research> all = null ;
		Map<String,Double> map = WordSimilarity.getWordsBySimilarity("����",MyTools.SIMILARITY) ;
		try {
			all = DaoFactory.getResearchDaoInstance().getByKeywordMap(map,1,10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Research> iter = all.iterator() ;
		while(iter.hasNext()){
			Research research = iter.next() ;
			System.out.println(research.getTopic()+"\t"+research.getContent()) ;
		}
	}
	public void testGetById(){
		Research research = null ;
		try {
			research = DaoFactory.getResearchDaoInstance().getById("123456789") ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(research.getAuthor()) ;
	}
	public void testGetByAuthor(){
		List<Research> all = null ;
		try {
			all = DaoFactory.getResearchDaoInstance().getByAuthor("�ص·�",2,2) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Research> iter = all.iterator() ;
		while(iter.hasNext()){
			Research research = iter.next() ;
			System.out.println(research.getTopic()+"\t"+research.getContent()) ;
		}
	}
}
