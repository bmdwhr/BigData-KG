package org.ws.dao;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.util.MD5Code;
import org.ws.vo.person.Person;

public class PersonDaoTest extends TestCase {
	private MD5Code md5 = new MD5Code() ;
	public void testLogin(){
		boolean flag = false ;
		Person person = new Person() ;
		person.setUserid("40109124") ;
		person.setUserpwd(md5.getMD5ofStr("ws153,.")) ;
		try {
			flag = DaoFactory.getPersonDaoInstance().login(person) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(flag);
		System.out.println(person.getName());
	}
	public void testGetAvgByCondition(){
		float avg = 0f ;
		try {
			avg = DaoFactory.getPersonDaoInstance().getAvgByCondition("wages") ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(avg) ;
	}
	
	public void testGetByName(){
		Person p = null ;
		try {
			p = DaoFactory.getPersonDaoInstance().getByName("�ص·�");
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(p!=null){
			System.out.print(p.getName()+"    \t") ;
			System.out.println(p.getResearchDirections()) ;
		}
	}
}
