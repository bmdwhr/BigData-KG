package org.ws.dao;

import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.vo.house.House;

public class HouseDaoTest extends TestCase {
	
	public void testGetByBSD(){
		List<House> all = null ;
		try {
			all = DaoFactory.getHouseDaoInstance().getByUBD("price",280000 , 560000, "area",142 ,170 ,1700000, 1, 10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<House> iter = all.iterator() ;
		while(iter.hasNext()){
			House house = iter.next() ;
			System.out.println(house.getPrice()+"\t"+house.getArea()+"\t"+house.getrCP()) ;
		}
	}
}
