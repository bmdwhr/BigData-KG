package org.ws.dao;

import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.vo.discipline.Project;

public class ProjectDaoTest extends TestCase {
	
	public void testGetByOrganization(){
		List<Project> all = null ;
		try {
			all = DaoFactory.getProjectDaoInstance().getByOrganization("�й���ѧ������Ϣ", 1, 10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Project> iter = all.iterator() ;
		while(iter.hasNext()){
			Project project = iter.next() ;
			System.out.println(project.getName()+"\t"+project.getDiscipline().getName()) ;
		}
	}
}
