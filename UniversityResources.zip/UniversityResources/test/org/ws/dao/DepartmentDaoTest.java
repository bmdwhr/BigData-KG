package org.ws.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.WordSimilarity;
import org.ws.vo.organization.Department;

public class DepartmentDaoTest extends TestCase {
	public void testGetByKeyword(){
		Map<String,Double> map = WordSimilarity.getWordsBySimilarity("�Ƽ���",MyTools.SIMILARITY) ;
		List<Department> all = null ;
		try {
			all = DaoFactory.getDepartmentDaoInstance().getByKeywordMap(map,1,10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Department> iter = all.iterator() ;
		while(iter.hasNext()){
			Department dept = iter.next() ;
			System.out.println(dept.getIntroduction()) ;
		}
	}
	public void testGetById(){
		Department dept = null ;
		try {
			dept = DaoFactory.getDepartmentDaoInstance().getById("1254409") ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(dept.getIntroduction());
	}
}
