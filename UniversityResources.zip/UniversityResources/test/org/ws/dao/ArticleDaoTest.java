package org.ws.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.WordSimilarity;
import org.ws.vo.publication.Article;

public class ArticleDaoTest extends TestCase {
	public void testGetByKeyword(){
		List<Article> all = null ;
		Map<String,Double> map = WordSimilarity.getWordsBySimilarity("����",MyTools.SIMILARITY) ;
		try {
			all = DaoFactory.getArticleDaoInstance().getByKeywordMap(map,1,10) ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		Iterator<Article> iter = all.iterator() ;
		while(iter.hasNext()){
			Article article = iter.next() ;
			System.out.println(article.getTopic()+"\t"+article.getContent()) ;
		}
	}
}
