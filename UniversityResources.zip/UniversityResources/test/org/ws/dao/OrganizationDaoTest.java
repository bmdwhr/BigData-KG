package org.ws.dao;

import junit.framework.TestCase;

import org.ws.factory.DaoFactory;
import org.ws.vo.organization.Organization;

public class OrganizationDaoTest extends TestCase {
	
	public void testGetByName(){
		Organization org = null ;
		try {
			org = DaoFactory.getOrganizationDaoInstance().getByName("�й���ѧ������Ϣ");
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(org!=null){
			System.out.print(org.getName()+"    \t") ;
			System.out.println(org.getIntroduction()) ;
		}
	}
}
