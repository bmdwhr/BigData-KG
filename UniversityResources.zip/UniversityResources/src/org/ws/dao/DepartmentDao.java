package org.ws.dao;

import java.util.List;
import java.util.Map;

import org.ws.vo.organization.Department;

public interface DepartmentDao {
	
	public List<Department> getByKeywordMap(Map<String,Double> map,int currentPage,int lineSize) throws Exception ;
	public Department getById(String id) throws Exception ;
	
}
