package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ws.dao.ResearchDao;
import org.ws.tools.MyTools;
import org.ws.vo.work.Research;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.Rule;

public class ResearchDaoImpl implements ResearchDao {

	private OntModel model;
	private Query query;
	private QueryExecution qe;

	public ResearchDaoImpl(OntModel model) {
		this.model = model;
	}

	@Override
	public List<Research> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<Research> all = new ArrayList<Research>();
		boolean flag = true;// �ж��ǲ��ǵ�һ��
		StringBuffer allquery = new StringBuffer();
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?id ?topic ?author ?time ?amount ?content "
				+ " WHERE{?x rdf:type test:Research.?x test:id ?id.?x test:topic ?topic.?x test:author ?author"
				+ ".?x test:time ?time.?x test:amount ?amount.?x test:content ?content"
				+ ".FILTER(";
		// ��չ��ѯ
		for (String word : map.keySet()) {
			if (!flag) {
				allquery.append("||");
			}
			allquery = allquery.append("REGEX(?topic,\"" + word + "\",\"i\")");
			flag = false;
		}
		queryStr = queryStr + allquery.toString()
				+ ")} ORDER BY DESC(?amount) OFFSET " + (currentPage - 1)
				* lineSize + " LIMIT " + lineSize;// ��ҳ����
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			Research research = new Research();
			QuerySolution qs = rs.nextSolution();
			if (qs.getLiteral("?id") != null) {
				research.setId(qs.getLiteral("?id").getString());
			}
			if (qs.getLiteral("?topic") != null) {
				research.setTopic(qs.getLiteral("?topic").getString());
			}
			if (qs.getLiteral("?author") != null) {
				research.setAuthor(qs.getLiteral("?author").getString());
			}
			if (qs.getLiteral("?time") != null) {
				research.setTime(MyTools.sdf.parse(qs.getLiteral("?time")
						.getString()));
			}
			if (qs.getLiteral("?amount") != null) {
				research.setAmount(qs.getLiteral("?amount").getInt());
			}
			if (qs.getLiteral("?content") != null) {
				research.setContent(qs.getLiteral("?content").getString());
			}
			all.add(research);
		}
		qe.close() ;
		return all;
	}

	@Override
	public Research getById(String id) throws Exception {
		Research research = new Research();
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?id ?topic ?author ?time ?amount ?content "
				+ " WHERE{?x rdf:type test:Research.?x test:id ?id.?x test:topic ?topic.?x test:author ?author"
				+ ".?x test:time ?time.?x test:amount ?amount.?x test:content ?content"
				+ ".?x test:id \"" + id + "\"}";
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			QuerySolution qs = rs.nextSolution();
			if (qs.getLiteral("?id") != null) {
				research.setId(qs.getLiteral("?id").getString());
			}
			if (qs.getLiteral("?topic") != null) {
				research.setTopic(qs.getLiteral("?topic").getString());
			}
			if (qs.getLiteral("?author") != null) {
				research.setAuthor(qs.getLiteral("?author").getString());
			}
			if (qs.getLiteral("?time") != null) {
				research.setTime(MyTools.sdf.parse(qs.getLiteral("?time")
						.getString()));
			}
			if (qs.getLiteral("?amount") != null) {
				research.setAmount(qs.getLiteral("?amount").getInt());
			}
			if (qs.getLiteral("?content") != null) {
				research.setContent(qs.getLiteral("?content").getString());
			}
		}
		qe.close() ;
		return research;
	}

	@Override
	public List<Research> getByAuthor(String author, int currentPage,
			int lineSize) throws Exception {
		List<Research> all = new ArrayList<Research>();
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?id ?topic ?author ?time ?amount ?content "
				+ " WHERE{?x rdf:type test:Research.?x test:id ?id.?x test:topic ?topic.?x test:author ?author"
				+ ".?x test:time ?time.?x test:amount ?amount.?x test:content ?content"
				+ ".?x test:author \"" + author
				+ "\"} ORDER BY DESC(?amount) OFFSET "
				+ (currentPage - 1) * lineSize + " LIMIT " + lineSize;
		;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			Research research = new Research();
			QuerySolution qs = rs.nextSolution();
			if (qs.getLiteral("?id") != null) {
				research.setId(qs.getLiteral("?id").getString());
			}
			if (qs.getLiteral("?topic") != null) {
				research.setTopic(qs.getLiteral("?topic").getString());
			}
			if (qs.getLiteral("?author") != null) {
				research.setAuthor(qs.getLiteral("?author").getString());
			}
			if (qs.getLiteral("?time") != null) {
				research.setTime(MyTools.sdf.parse(qs.getLiteral("?time")
						.getString()));
			}
			if (qs.getLiteral("?amount") != null) {
				research.setAmount(qs.getLiteral("?amount").getInt());
			}
			if (qs.getLiteral("?content") != null) {
				research.setContent(qs.getLiteral("?content").getString());
			}
			all.add(research);
		}
		qe.close() ;
		return all;
	}

}
