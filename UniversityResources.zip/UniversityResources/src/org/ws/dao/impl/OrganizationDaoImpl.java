package org.ws.dao.impl;


import org.ws.dao.OrganizationDao;
import org.ws.tools.MyTools;
import org.ws.vo.area.Area;
import org.ws.vo.organization.Organization;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Resource;

public class OrganizationDaoImpl implements OrganizationDao{

	private OntModel model = null;
	private Query query = null;
	private QueryExecution qe = null;

	public OrganizationDaoImpl(OntModel model) {
		this.model = model;
	}
	
	@Override
	public Organization getByName(String name) throws Exception {
		Organization org = null ;
		String queryStr = MyTools.getQueryPrefix()
		+ "SELECT ?x "
		+ " WHERE{?x rdf:type test:Organization.?x test:name ?name.FILTER(REGEX(?name,\""+name+"\",\"i\"))}" ;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			org = new Organization() ;
			QuerySolution qs = rs.next();
			Resource resource = qs.getResource("?x") ;
			if (resource!= null) {
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"id"))!=null){
					String id = resource.getProperty(model.createProperty(MyTools.getURI()+"id")).getLiteral().getString() ;
					org.setId(id);
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"name"))!=null){
					String n = resource.getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					org.setName(n);
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"introduction"))!=null){
					String introduction = resource.getProperty(model.createProperty(MyTools.getURI()+"introduction")).getLiteral().getString() ;
					org.setIntroduction(introduction);
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"from"))!=null){
					String from = resource.getProperty(model.createProperty(MyTools.getURI()+"from")).getResource().getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					Area area = new Area() ; 
					area.setName(from);
					org.setArea(area) ;
				}
			}
		}
		qe.close() ;
		return org ;
	}
	
}
