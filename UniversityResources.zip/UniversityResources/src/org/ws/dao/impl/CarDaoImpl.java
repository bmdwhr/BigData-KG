package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.ws.dao.CarDao;
import org.ws.tools.MyTools;
import org.ws.vo.car.Car;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

public class CarDaoImpl implements CarDao {

	private OntModel model = null;
	private Query query = null;
	private QueryExecution qe = null;

	public CarDaoImpl(OntModel model) {
		this.model = model;
	}

	@Override
	public List<Car> getByBSD(float min, float max, String brand,
			int currentPage, int lineSize) throws Exception {
		List<Car> all = new ArrayList<Car>();
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?id ?brand ?price ?version ?satisfaction "
				+ " WHERE { ?x rdf:type test:Car.?x rdf:type test:TOP.?x test:id ?id .?x test:brand ?brand.?x test:price ?price.?x test:satisfaction ?satisfaction";
		queryStr = queryStr + ".FILTER((?price>="+min+"&&?price<="+max+")&&(?brand!=\""+brand+"\")) }" ;
		queryStr = queryStr + " OFFSET " + (currentPage - 1)* lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet result = qe.execSelect();
		while (result.hasNext()) {
			Car car = new Car();
			QuerySolution qs = result.nextSolution();
			if (qs.getLiteral("?id") != null) {
				car.setId(qs.getLiteral("?id").getString());
			}
			if (qs.getLiteral("?brand") != null) {
				car.setBrand(qs.getLiteral("?brand").getString());
			}
			if (qs.getLiteral("?price") != null) {
				car.setPrice(qs.getLiteral("?price").getFloat());
				if (qs.getLiteral("?satisfaction") != null) {
					float satisfaction = qs.getLiteral("?satisfaction").getFloat();
					float uPrice = car.getPrice()/max ;
					if(satisfaction>=uPrice){
						car.setuC(uPrice) ;
					}else{
						car.setuC(satisfaction) ;
					}
					if(1-satisfaction>=1-uPrice){
						car.setuP(1-satisfaction) ;
					}else{
						car.setuP(1-uPrice) ;
					}
					float rCP = car.getuC()/(car.getuC()+car.getuP())*((1-car.getuP())/(2-car.getuC()-car.getuP()))  ;
					car.setrCP(rCP) ;
				}
			}
			if (qs.getLiteral("?version") != null) {
				car.setVersion(qs.getLiteral("?version").getString());
			}
			all.add(car);
		}
		qe.close();
		return all ;
	}

}
