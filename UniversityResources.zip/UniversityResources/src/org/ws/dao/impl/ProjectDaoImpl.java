package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.ws.dao.ProjectDao;
import org.ws.tools.MyTools;
import org.ws.vo.discipline.Discipline;
import org.ws.vo.discipline.Project;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Resource;

public class ProjectDaoImpl implements ProjectDao {

	private OntModel model = null;
	private Query query = null;
	private QueryExecution qe = null;

	public ProjectDaoImpl(OntModel model) {
		this.model = model;
	}
	
	@Override
	public List<Project> getByOrganization(String orgname,int currentPage,int lineSize) throws Exception {
		List<Project> all = new ArrayList<Project>() ;
		String queryStr = MyTools.getQueryPrefix()
		+ " SELECT ?x "
		+ " WHERE { ?x rdf:type test:Project.?x test:by_organization ?org.?org test:name ?orgname";
		queryStr = queryStr + ".FILTER(REGEX(?orgname,\""+orgname+"\",\"i\"))}" ;
		queryStr = queryStr + " OFFSET " + (currentPage - 1)* lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet result = qe.execSelect();
		while (result.hasNext()) {
			Project pro = new Project() ;
			QuerySolution qs = result.nextSolution();
			Resource resource = qs.getResource("?x") ;
			if (resource!= null) {
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"id"))!=null){
					String id = resource.getProperty(model.createProperty(MyTools.getURI()+"id")).getLiteral().getString() ;
					pro.setId(id);
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"name"))!=null){
					String n = resource.getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					pro.setName(n) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"belong"))!=null){
					Resource r = resource.getProperty(model.createProperty(MyTools.getURI()+"belong")).getResource() ;
					String id = r.getProperty(model.createProperty(MyTools.getURI()+"id")).getLiteral().getString() ;
					String name = r.getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					Discipline discipline = new Discipline() ;
					discipline.setId(id);
					discipline.setName(name);
					pro.setDiscipline(discipline) ;
				}
				all.add(pro);
			}
		}
		qe.close() ;
		return all ;
	}

}
