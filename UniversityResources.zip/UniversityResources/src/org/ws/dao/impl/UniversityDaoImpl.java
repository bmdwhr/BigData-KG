package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ws.dao.UniversityDao;
import org.ws.tools.MyTools;
import org.ws.vo.area.Area;
import org.ws.vo.major.Major;
import org.ws.vo.organization.University;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.Rule;

public class UniversityDaoImpl implements UniversityDao {
	private OntModel model;
	private Query query;
	private QueryExecution qe;

	public UniversityDaoImpl(OntModel model) {
		this.model = model;
	}

	@Override
	public List<University> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<University> all = new ArrayList<University>();
		boolean flag = true;
		StringBuffer allQuery = new StringBuffer();
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ "SELECT ?x "
				+ " WHERE{?x rdf:type test:University.?x test:name ?name"
				+ ".FILTER(";
		for (String word : map.keySet()) {
			if (!flag) {
				allQuery.append("||");
			}
			allQuery.append("REGEX(?name,\"" + word + "\",\"i\")");
			flag = false;
		}
		queryStr = queryStr + allQuery.toString() + ")} ORDER BY ?id OFFSET "
				+ (currentPage - 1) * lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			University uni = new University();
			QuerySolution qs = rs.next();
			Resource resource = qs.getResource("?x") ;
			if (resource!= null) {
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"id"))!=null){
					String id = resource.getProperty(model.createProperty(MyTools.getURI()+"id")).getLiteral().getString() ;
					uni.setId(id);
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"name"))!=null){
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					uni.setName(name) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"introduction"))!=null){
					String introduction = resource.getProperty(model.createProperty(MyTools.getURI()+"introduction")).getLiteral().getString() ;
					uni.setIntroduction(introduction) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"college_have"))!=null){
					List<Major> list = new ArrayList<Major>() ;
					Major m = new Major() ; 
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"college_have")).getResource().getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					m.setName(name) ;
					list.add(m) ;
					uni.setMarjors(list) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"college_from"))!=null){
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"college_from")).getResource().getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					Area area = new Area() ; 
					area.setName(name);
					uni.setArea(area) ;
				}
				all.add(uni);
			}
		}
		qe.close() ;
		return all;
	}

	@Override
	public University getById(String id) throws Exception {
		University uni = new University();
		String queryStr = MyTools.getQueryPrefix()
				+ "SELECT ?id ?name ?introduction "
				+ " WHERE{?x rdf:type test:University.?x test:id ?id.?x test:name ?name.?x test:introduction ?introduction"
				+ ".FILTER(?id=\"" + id + "\")}";
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			if (qs.get("?id") != null) {
				uni.setId(qs.getLiteral("?id").getString());
			}
			if (qs.get("?name") != null) {
				uni.setName(qs.getLiteral("?name").getString());
			}
			if (qs.get("?introduction") != null) {
				uni.setIntroduction(qs.getLiteral("?introduction").getString());
			}
		}
		qe.close() ;
		return uni;
	}

	@Override
	public List<University> getByMajor(String major,int currentPage,int lineSize) throws Exception {
		List<University> all = new ArrayList<University>() ;
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?x"
				+ " WHERE{?x rdf:type test:University"
				+".?x test:college_have test:"+major
				+"}ORDER BY ?id OFFSET "
				+ (currentPage - 1) * lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			University uni = new University();
			QuerySolution qs = rs.next();
			Resource resource = qs.getResource("?x") ;
			if (resource!= null) {
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"id"))!=null){
					String id = resource.getProperty(model.createProperty(MyTools.getURI()+"id")).getLiteral().getString() ;
					uni.setId(id);
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"name"))!=null){
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					uni.setName(name) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"introduction"))!=null){
					String introduction = resource.getProperty(model.createProperty(MyTools.getURI()+"introduction")).getLiteral().getString() ;
					uni.setIntroduction(introduction) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"college_have"))!=null){
					List<Major> list = new ArrayList<Major>() ;
					Major m = new Major() ; 
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"college_have")).getResource().getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					m.setName(name) ;
					list.add(m) ;
					uni.setMarjors(list) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"college_from"))!=null){
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"college_from")).getResource().getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					Area area = new Area() ; 
					area.setName(name);
					uni.setArea(area) ;
				}
				all.add(uni);
			}
		}
		qe.close() ;
		return all ;
	}

	@Override
	public List<University> getByArea(String area, int currentPage, int lineSize)
			throws Exception {
		List<University> all = new ArrayList<University>() ;
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?x"
				+ " WHERE{?x rdf:type test:University"
				+".?x test:college_from ?area.?area rdf:type test:"+area
				+"}ORDER BY ?id OFFSET "
				+ (currentPage - 1) * lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			University uni = new University();
			QuerySolution qs = rs.next();
			Resource resource = qs.getResource("?x") ;
			if (resource!= null) {
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"id"))!=null){
					String id = resource.getProperty(model.createProperty(MyTools.getURI()+"id")).getLiteral().getString() ;
					uni.setId(id);
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"name"))!=null){
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					uni.setName(name) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"introduction"))!=null){
					String introduction = resource.getProperty(model.createProperty(MyTools.getURI()+"introduction")).getLiteral().getString() ;
					uni.setIntroduction(introduction) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"college_have"))!=null){
					List<Major> list = new ArrayList<Major>() ;
					Major m = new Major() ; 
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"college_have")).getResource().getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					m.setName(name) ;
					list.add(m) ;
					uni.setMarjors(list) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"college_from"))!=null){
					String name = resource.getProperty(model.createProperty(MyTools.getURI()+"college_from")).getResource().getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					Area a = new Area() ; 
					a.setName(name);
					uni.setArea(a) ;
				}
				all.add(uni);
			}
		}
		qe.close() ;
		return all;
	}
	
}

