package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.ws.dao.HouseDao;
import org.ws.tools.MyTools;
import org.ws.vo.house.House;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.Rule;

public class HouseDaoImpl implements HouseDao {

	private OntModel model = null;
	private Query query = null;
	private QueryExecution qe = null;

	public HouseDaoImpl(OntModel model) {
		this.model = model;
	}

	@Override
	public List<House> getByUBD(String condition1, float min1, float max1,
			String condition2, float min2, float max2, float m,
			int currentPage, int lineSize) {
		List<House> all = new ArrayList<House>();
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?id ?price ?area ((?condition1/"
				+ m
				+ ") AS ?x1) (IF(?x1>0.5,?x1,(1-?x1)) AS ?uC) ((1-?uC) AS ?uP) ((?uC-?uP) AS ?rCP)"
				+ " WHERE { ?x rdf:type test:House.?x test:id ?id .?x test:price ?price.?x test:area ?area";
		queryStr = queryStr + ". ?x test:" + condition1
				+ " ?condition1 . ?x test:" + condition2
				+ " ?condition2 .FILTER((?condition1>=" + min1
				+ "&&?condition1<=" + max1 + ")||(?condition2>=" + min2
				+ "&&?condition2<=" + max2 + ")) }";
		queryStr = queryStr + " ORDER BY DESC(?rCP) OFFSET "
				+ (currentPage - 1) * lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet result = qe.execSelect();
		while (result.hasNext()) {
			House house = new House();
			QuerySolution qs = result.nextSolution();
			if (qs.getLiteral("?id") != null) {
				house.setId(qs.getLiteral("?id").getString());
			}
			if (qs.getLiteral("?price") != null) {
				house.setPrice(qs.getLiteral("?price").getFloat());
			}
			if (qs.getLiteral("?area") != null) {
				house.setArea(qs.getLiteral("?area").getFloat());
			}
			if (qs.getLiteral("?uC") != null) {
				house.setuC(qs.getLiteral("?uC").getFloat());
			}
			if (qs.getLiteral("?uP") != null) {
				house.setuP(qs.getLiteral("?uP").getFloat());
			}
			if (qs.getLiteral("?rCP") != null) {
				house.setrCP(qs.getLiteral("?rCP").getFloat());
			}
			all.add(house);
		}
		qe.close();
		return all;
	}

}
