package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ws.dao.FacultyDao;
import org.ws.tools.MyTools;
import org.ws.vo.person.Faculty;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.Rule;

public class FacultyDaoImpl implements FacultyDao {
	private OntModel model = null;
	private Query query = null;
	private QueryExecution qe = null;

	public FacultyDaoImpl(OntModel model) {
		this.model = model;
	}
	
	@Override
	public int getCountByConditionRange(String condition, float min, float max,
			int flag) throws Exception {
		int count = 0 ;
		return count ;
	}

	@Override
	public List<Faculty> getByConditionRange(String condition, float min,
			float max, int flag, int currentPage, int lineSize)
			throws Exception {
		List<Faculty> all = new ArrayList<Faculty>();
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?name ?sex ?birthday ?nation ?telephone ?email ?remarks ?workload ?wages ?workplace ?specialty ?technicalTitles"
				+ " WHERE{?x rdf:type test:Faculty.?x test:name ?name .?x test:sex ?sex.?x test:birthday ?birthday.?x test:nation ?nation"
				+ ".OPTIONAL{?x test:telephone ?telephone}.OPTIONAL{?x test:email ?email}.OPTIONAL{?x test:remarks ?remarks}.?x test:workload ?workload.?x test:wages ?wages"
				+ ".?x test:workplace ?workplace.OPTIONAL{?x test:specialty ?specialty}.OPTIONAL{?x test:technicalTitles ?technicalTitles}";
		if (flag == 1) {
			// ����
			queryStr = queryStr + ". ?x test:" + condition
					+ " ?condition .FILTER(?condition >= " + min + ")}";
		} else if (flag == 2) {
			// ����
			queryStr = queryStr + ". ?x test:" + condition
					+ " ?condition .FILTER(?condition <= " + max + ")}";
		} else if (flag == 3) {
			// ��Χ
			queryStr = queryStr + ". ?x test:" + condition
					+ " ?condition .FILTER(?condition >= " + min
					+ " &&?condition <=" + max + ")}";
		}
		queryStr = queryStr + " order by ?condition OFFSET " + (currentPage - 1)
				* lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet result = qe.execSelect();
		while (result.hasNext()) {
			Faculty faculty = new Faculty();
			QuerySolution qs = result.nextSolution();
			if (qs.getLiteral("?name") != null) {
				faculty.setName(qs.getLiteral("?name").getString());
			}
			if (qs.getLiteral("?sex") != null) {
				faculty.setSex(qs.getLiteral("?sex").getString());
			}
			if (qs.getLiteral("?birthday") != null) {
				faculty.setBirthday(MyTools.sdf.parse(qs
						.getLiteral("?birthday").getString()));
			}
			if (qs.getLiteral("?nation") != null) {
				faculty.setNation(qs.getLiteral("?nation").getString());
			}
			if (qs.getLiteral("?telephone") != null) {
				faculty.setTelephone(qs.getLiteral("?telephone").getString());
			}
			if (qs.getLiteral("?email") != null) {
				faculty.setEmail(qs.getLiteral("?email").getString());
			}
			if (qs.getLiteral("?remarks") != null) {
				faculty.setRemarks(qs.getLiteral("?remarks").getString());
			}
			if (qs.getLiteral("?workload") != null) {
				faculty.setWorkload(qs.getLiteral("?workload").getInt());
			}
			if (qs.getLiteral("?wages") != null) {
				faculty.setWages(qs.getLiteral("?wages").getFloat());
			}
			if (qs.getLiteral("?workplace") != null) {
				faculty.setWorkplace(qs.getLiteral("?workplace").getString());
			}
			if (qs.getLiteral("?specialty") != null) {
				faculty.setSpecialty(qs.getLiteral("?specialty").getString());
			}
			if (qs.getLiteral("?technicalTitles") != null) {
				faculty.setTechnicalTitles(qs.getLiteral("?technicalTitles")
						.getString());
			}
			all.add(faculty);
		}
		qe.close();
		return all;
	}

	@Override
	public List<Faculty> getByKeyword(String keyword,
			int currentPage, int lineSize) throws Exception {
		List<Faculty> all = new ArrayList<Faculty>();
		StringBuffer allquery = new StringBuffer();
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?name ?sex ?birthday ?nation ?telephone ?email ?remarks ?workload ?wages ?workplace ?specialty ?technicalTitles"
				+ " WHERE{?x rdf:type test:Faculty.?x test:name ?name .?x test:sex ?sex.?x test:birthday ?birthday.?x test:nation ?nation"
				+ ".OPTIONAL{?x test:telephone ?telephone}.OPTIONAL{?x test:email ?email}.OPTIONAL{?x test:remarks ?remarks}.?x test:workload ?workload.?x test:wages ?wages"
				+ ".?x test:workplace ?workplace.OPTIONAL{?x test:specialty ?specialty}.OPTIONAL{?x test:technicalTitles ?technicalTitles}"
				+ ".FILTER(";
		allquery = allquery.append("REGEX(?name,\"" + keyword
				+ "\",\"i\")||REGEX(?sex,\"" + keyword 
				+ "\",\"i\")||REGEX(?workplace,\"" + keyword 
				+ "\",\"i\")||REGEX(?specialty,\"" + keyword
				+ "\",\"i\")||REGEX(?technicalTitles,\"" + keyword
				+ "\",\"i\")");
		queryStr = queryStr + allquery.toString() + ")} OFFSET "
				+ (currentPage - 1) * lineSize + " LIMIT " + lineSize;// ��ҳ����
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			Faculty faculty = new Faculty();
			QuerySolution qs = rs.nextSolution();
			if (qs.getLiteral("?name") != null) {
				faculty.setName(qs.getLiteral("?name").getString());
			}
			if (qs.getLiteral("?sex") != null) {
				faculty.setSex(qs.getLiteral("?sex").getString());
			}
			if (qs.getLiteral("?birthday") != null) {
				faculty.setBirthday(MyTools.sdf.parse(qs
						.getLiteral("?birthday").getString()));
			}
			if (qs.getLiteral("?nation") != null) {
				faculty.setNation(qs.getLiteral("?nation").getString());
			}
			if (qs.getLiteral("?telephone") != null) {
				faculty.setTelephone(qs.getLiteral("?telephone").getString());
			}
			if (qs.getLiteral("?email") != null) {
				faculty.setEmail(qs.getLiteral("?email").getString());
			}
			if (qs.getLiteral("?remarks") != null) {
				faculty.setRemarks(qs.getLiteral("?remarks").getString());
			}
			if (qs.getLiteral("?workload") != null) {
				faculty.setWorkload(qs.getLiteral("?workload").getInt());
			}
			if (qs.getLiteral("?wages") != null) {
				faculty.setWages(qs.getLiteral("?wages").getFloat());
			}
			if (qs.getLiteral("?workplace") != null) {
				faculty.setWorkplace(qs.getLiteral("?workplace").getString());
			}
			if (qs.getLiteral("?specialty") != null) {
				faculty.setSpecialty(qs.getLiteral("?specialty").getString());
			}
			if (qs.getLiteral("?technicalTitles") != null) {
				faculty.setTechnicalTitles(qs.getLiteral("?technicalTitles")
						.getString());
			}
			all.add(faculty);
		}
		qe.close() ;
		return all;
	}
	
	@Override
	public List<Faculty> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<Faculty> all = new ArrayList<Faculty>();
		StringBuffer allquery = new StringBuffer();
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		boolean flag = true;// �ж��ǲ��ǵ�һ��
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ?name ?sex ?birthday ?nation ?telephone ?email ?remarks ?workload ?wages ?workplace ?specialty ?technicalTitles"
				+ " WHERE{?x rdf:type test:Faculty.?x test:name ?name .?x test:sex ?sex.?x test:birthday ?birthday.?x test:nation ?nation"
				+ ".OPTIONAL{?x test:telephone ?telephone}.OPTIONAL{?x test:email ?email}.OPTIONAL{?x test:remarks ?remarks}.?x test:workload ?workload.?x test:wages ?wages"
				+ ".?x test:workplace ?workplace.OPTIONAL{?x test:specialty ?specialty}.OPTIONAL{?x test:technicalTitles ?technicalTitles}"
				+ ".FILTER(";
		// ��չ��ѯ
		for (String word : map.keySet()) {
			if (!flag) {
				allquery.append("||");
			}
			allquery = allquery.append("REGEX(?name,\"" + word
					+ "\",\"i\")||REGEX(?workplace,\"" + word + "\",\"i\")"
					+ "||REGEX(?specialty,\"" + word
					+ "\",\"i\")||REGEX(?technicalTitles,\"" + word
					+ "\",\"i\")");
			flag = false;
		}
		queryStr = queryStr + allquery.toString() + ")} OFFSET "
				+ (currentPage - 1) * lineSize + " LIMIT " + lineSize;// ��ҳ����
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			Faculty faculty = new Faculty();
			QuerySolution qs = rs.nextSolution();
			if (qs.getLiteral("?name") != null) {
				faculty.setName(qs.getLiteral("?name").getString());
			}
			if (qs.getLiteral("?sex") != null) {
				faculty.setSex(qs.getLiteral("?sex").getString());
			}
			if (qs.getLiteral("?birthday") != null) {
				faculty.setBirthday(MyTools.sdf.parse(qs
						.getLiteral("?birthday").getString()));
			}
			if (qs.getLiteral("?nation") != null) {
				faculty.setNation(qs.getLiteral("?nation").getString());
			}
			if (qs.getLiteral("?telephone") != null) {
				faculty.setTelephone(qs.getLiteral("?telephone").getString());
			}
			if (qs.getLiteral("?email") != null) {
				faculty.setEmail(qs.getLiteral("?email").getString());
			}
			if (qs.getLiteral("?remarks") != null) {
				faculty.setRemarks(qs.getLiteral("?remarks").getString());
			}
			if (qs.getLiteral("?workload") != null) {
				faculty.setWorkload(qs.getLiteral("?workload").getInt());
			}
			if (qs.getLiteral("?wages") != null) {
				faculty.setWages(qs.getLiteral("?wages").getFloat());
			}
			if (qs.getLiteral("?workplace") != null) {
				faculty.setWorkplace(qs.getLiteral("?workplace").getString());
			}
			if (qs.getLiteral("?specialty") != null) {
				faculty.setSpecialty(qs.getLiteral("?specialty").getString());
			}
			if (qs.getLiteral("?technicalTitles") != null) {
				faculty.setTechnicalTitles(qs.getLiteral("?technicalTitles")
						.getString());
			}
			all.add(faculty);
		}
		qe.close() ;
		return all;
	}

	//˫��ƫ�ò�ѯ
	@Override
	public List<Faculty> getByBSD(String condition1, float min1, float max1,float m1,
			int flag1, String condition2, float min2, float max2, float m2,int flag2,
			int currentPage, int lineSize) throws Exception {
		List<Faculty> all = new ArrayList<Faculty>();
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ " SELECT ((?condition1/"+m1+") AS ?x1) (IF(?x1>0.5,?x1,(1-?x1)) AS ?u1) ((?condition2/"+m2+") AS ?x2) (IF(?x2>0.5,?x2,(1-?x2)) AS ?u2) (IF(?u1<?u2,?u1,?u2) AS ?uC) (IF((1-?u1)>(1-?u2),(1-?u1),(1-?u2)) AS ?uP) ((?uC/(?uC+?uP)*(1-?uP)/(2-?uC-?uP))AS ?rCP) ?name ?sex ?birthday ?nation ?telephone ?email ?remarks ?workload ?wages ?workplace ?specialty ?technicalTitles"
				+ " WHERE{?x rdf:type test:Faculty.?x test:name ?name .?x test:sex ?sex.?x test:birthday ?birthday.?x test:nation ?nation"
				+ ".OPTIONAL{?x test:telephone ?telephone}.OPTIONAL{?x test:email ?email}.OPTIONAL{?x test:remarks ?remarks}.?x test:workload ?workload.?x test:wages ?wages"
				+ ".?x test:workplace ?workplace.OPTIONAL{?x test:specialty ?specialty}.OPTIONAL{?x test:technicalTitles ?technicalTitles}";
		if (flag1 == 1) {
			// ����
			queryStr = queryStr + ". ?x test:" + condition1
					+ " ?condition1 .FILTER(?condition1 >= " + min1 + ")";
		} else if (flag1 == 2) {
			// ����
			queryStr = queryStr + ". ?x test:" + condition1
					+ " ?condition1 .FILTER(?condition1 <= " + max1 + ")";
		} else if (flag1 == 3) {
			// ��Χ
			queryStr = queryStr + ". ?x test:" + condition1
					+ " ?condition1 .FILTER(?condition1 >= " + min1
					+ " &&?condition1 <=" + max1 + ")";
		}
		if (flag2 == 1) {
			// ����
			queryStr = queryStr + ". ?x test:" + condition2
					+ " ?condition2 .FILTER(?condition2 >= " + min2 + ")}";
		} else if (flag2 == 2) {
			// ����
			queryStr = queryStr + ". ?x test:" + condition2
					+ " ?condition2 .FILTER(?condition2 <= " + max2 + ")}";
		} else if (flag2 == 3) {
			// ��Χ
			queryStr = queryStr + ". ?x test:" + condition2
					+ " ?condition2 .FILTER(?condition2 >= " + min2
					+ " &&?condition2 <=" + max2 + ")}";
		}
		queryStr = queryStr + " order by DESC(?rCP) OFFSET " + (currentPage - 1)
				* lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet result = qe.execSelect();
		while (result.hasNext()) {
			Faculty faculty = new Faculty();
			QuerySolution qs = result.nextSolution();
			if (qs.getLiteral("?name") != null) {
				faculty.setName(qs.getLiteral("?name").getString());
			}
			if (qs.getLiteral("?sex") != null) {
				faculty.setSex(qs.getLiteral("?sex").getString());
			}
			if (qs.getLiteral("?birthday") != null) {
				faculty.setBirthday(MyTools.sdf.parse(qs
						.getLiteral("?birthday").getString()));
			}
			if (qs.getLiteral("?nation") != null) {
				faculty.setNation(qs.getLiteral("?nation").getString());
			}
			if (qs.getLiteral("?telephone") != null) {
				faculty.setTelephone(qs.getLiteral("?telephone").getString());
			}
			if (qs.getLiteral("?email") != null) {
				faculty.setEmail(qs.getLiteral("?email").getString());
			}
			if (qs.getLiteral("?remarks") != null) {
				faculty.setRemarks(qs.getLiteral("?remarks").getString());
			}
			if (qs.getLiteral("?workload") != null) {
				faculty.setWorkload(qs.getLiteral("?workload").getInt());
			}
			if (qs.getLiteral("?wages") != null) {
				faculty.setWages(qs.getLiteral("?wages").getFloat());
			}
			if (qs.getLiteral("?workplace") != null) {
				faculty.setWorkplace(qs.getLiteral("?workplace").getString());
			}
			if (qs.getLiteral("?specialty") != null) {
				faculty.setSpecialty(qs.getLiteral("?specialty").getString());
			}
			if (qs.getLiteral("?technicalTitles") != null) {
				faculty.setTechnicalTitles(qs.getLiteral("?technicalTitles").getString());
			}
			if (qs.getLiteral("?uC") != null) {
				faculty.setuC(qs.getLiteral("?uC").getFloat()) ;
			}
			if (qs.getLiteral("?uP") != null) {
				faculty.setuP(qs.getLiteral("?uP").getFloat()) ;
			}
			if (qs.getLiteral("?rCP") != null) {
				faculty.setrCP(qs.getLiteral("?rCP").getFloat()) ;
			}
			all.add(faculty);
		}
		qe.close();
		return all;
	}

}
