package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ws.dao.DepartmentDao;
import org.ws.tools.MyTools;
import org.ws.vo.organization.Department;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.Rule;

public class DepartmentDaoImpl implements DepartmentDao {
	private OntModel model = null;
	private Query query = null;
	private QueryExecution qe;

	public DepartmentDaoImpl(OntModel model) {
		this.model = model;
	}

	@Override
	public List<Department> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<Department> all = new ArrayList<Department>();
		boolean flag = true;
		StringBuffer allQuery = new StringBuffer();
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ "SELECT ?id ?name ?introduction "
				+ " WHERE{?x rdf:type test:Department.?x test:id ?id.?x test:name ?name.?x test:introduction ?introduction"
				+ ".FILTER(";
		for (String word : map.keySet()) {
			if (!flag) {
				allQuery.append("||");
			}
			allQuery.append("REGEX(?name,\"" + word + "\",\"i\")");
			flag = false;
		}
		queryStr = queryStr + allQuery.toString() + ")} ORDER BY ?id OFFSET "
				+ (currentPage - 1) * lineSize + " LIMIT " + lineSize;
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			Department dept = new Department();
			QuerySolution qs = rs.next();
			if (qs.get("?id") != null) {
				dept.setId(qs.getLiteral("?id").getString());
			}
			if (qs.get("?name") != null) {
				dept.setName(qs.getLiteral("?name").getString());
			}
			if (qs.get("?introduction") != null) {
				dept.setIntroduction(qs.getLiteral("?introduction")
								.getString());
			}
			all.add(dept);
		}
		qe.close() ;
		return all;
	}

	@Override
	public Department getById(String id) throws Exception {
		Department dept = new Department();
		String queryStr = MyTools.getQueryPrefix()
				+ "SELECT ?id ?name ?introduction "
				+ " WHERE{?x rdf:type test:Department.?x test:id ?id.?x test:name ?name.?x test:introduction ?introduction"
				+ ".FILTER(?id=\"" + id + "\")}";
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			QuerySolution qs = rs.next();
			if (qs.get("?id") != null) {
				dept.setId(qs.getLiteral("?id").getString());
			}
			if (qs.get("?name") != null) {
				dept.setName(qs.getLiteral("?name").getString());
			}
			if (qs.get("?introduction") != null) {
				dept.setIntroduction(qs.getLiteral("?introduction")
								.getString());
			}
		}
		qe.close() ;
		return dept;
	}

}
