package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ws.dao.ArticleDao;
import org.ws.tools.MyTools;
import org.ws.vo.publication.Article;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.Rule;

public class ArticleDaoImpl implements ArticleDao {

	private OntModel model;
	private Query query;
	private QueryExecution qe;

	public ArticleDaoImpl(OntModel model) {
		this.model = model;
	}

	@Override
	public List<Article> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<Article> all = new ArrayList<Article>();
		boolean flag = true;// �ж��ǲ��ǵ�һ��
		StringBuffer allquery = new StringBuffer();
		Reasoner reasoner = new GenericRuleReasoner(Rule.parseRules(MyTools.getRules())); //����������󶨵�������
		InfModel inf = ModelFactory.createInfModel(reasoner, model); //��������ģ��
		String queryStr = MyTools.getQueryPrefix()
				+ "SELECT ?id ?topic ?publisher ?time ?amount ?content "
				+ " WHERE{?x rdf:type test:Article.?x test:id ?id.?x test:topic ?topic.?x test:publisher ?publisher."
				+ "?x test:time ?time.?x test:amount ?amount.?x test:content ?content"
				+ ".FILTER(";
		// ��չ��ѯ
		for (String word : map.keySet()) {
			if (!flag) {
				allquery.append("||");
			}
			allquery = allquery.append("REGEX(?topic,\"" + word + "\",\"i\")");
			flag = false;
		}
		queryStr = queryStr + allquery.toString()
				+ ")} ORDER BY DESC(?amount) OFFSET " + (currentPage - 1)
				* lineSize + " LIMIT " + lineSize;// ��ҳ����
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, inf);
		ResultSet rs = qe.execSelect();
		while (rs.hasNext()) {
			Article article = new Article();
			QuerySolution qs = rs.nextSolution();
			if (qs.getLiteral("?id") != null) {
				article.setId(qs.getLiteral("?id").getString());
			}
			if (qs.getLiteral("?topic") != null) {
				article.setTopic(qs.getLiteral("?topic").getString());
			}
			if (qs.getLiteral("?publisher") != null) {
				article.setPublisher(qs.getLiteral("?publisher").getString());
			}
			if (qs.getLiteral("?time") != null) {
				article.setTime(MyTools.sdf.parse(qs.getLiteral("?time")
						.getString()));
			}
			if (qs.getLiteral("?amount") != null) {
				article.setAmount(qs.getLiteral("?amount").getInt());
			}
			if (qs.getLiteral("?content") != null) {
				article.setContent(qs.getLiteral("?content").getString());
			}
			all.add(article);
		}
		qe.close() ;
		return all;
	}

}
