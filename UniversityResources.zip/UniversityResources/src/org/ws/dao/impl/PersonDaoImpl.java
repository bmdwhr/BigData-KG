package org.ws.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ws.dao.PersonDao;
import org.ws.tools.MyTools;
import org.ws.vo.person.Person;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Resource;

public class PersonDaoImpl implements PersonDao {
	private OntModel model = null ;
	private Query query = null ;
	private QueryExecution qe = null ;
	public PersonDaoImpl(OntModel model){
		this.model = model ;
	}
	@Override
	public boolean login(Person person) throws Exception {
		boolean flag = false ;
		String queryStr = MyTools.getQueryPrefix()+" Select ?name "
        +" Where{?x rdf:type test:Person.?x test:userid \""+person.getUserid()+"\".?x test:userpwd \""+person.getUserpwd()+"\".?x test:name ?name}"; 
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet rs = qe.execSelect() ;
		while(rs.hasNext()){
			QuerySolution qs =  rs.nextSolution();
			person.setName(qs.getLiteral("?name").getString()) ;
			flag = true ;
		}
		qe.close() ;
		return flag ;
	}
	@Override
	public float getAvgByCondition(String condition) throws Exception {
		float avg = 0f ;
		float sum = 0f ;
		String queryStr = MyTools.getQueryPrefix()+ "SELECT ?condition "
		+" WHERE{?x rdf:type test:Person.?x test:"+condition+" ?condition}" ;
		query = QueryFactory.create(queryStr) ;
		qe = QueryExecutionFactory.create(query, model) ;
		ResultSet rs = qe.execSelect() ;
		while(rs.hasNext()){
			QuerySolution qs = rs.nextSolution() ;
			sum = sum+qs.getLiteral("?condition").getFloat() ;
		}
		avg = sum / rs.getRowNumber() ;
		qe.close() ;
		return avg ;
	}
	@Override
	public List<Person> getByKeywordMap(Map<String,Double> map, int currentPage,
			int lineSize) throws Exception {
		List<Person> all = new ArrayList<Person>() ;
		return all ;
	}
	
	@Override
	public Person getByName(String name) throws Exception {
		Person person = null  ;
		String queryStr = MyTools.getQueryPrefix()+" Select ?x "
        +" Where{?x rdf:type test:Person.?x test:name \""+name+"\"}"; 
		query = QueryFactory.create(queryStr);
		qe = QueryExecutionFactory.create(query, model);
		ResultSet rs = qe.execSelect() ;
		while(rs.hasNext()){
			person = new Person() ;
			QuerySolution qs =  rs.nextSolution();
			Resource resource = qs.getResource("?x") ;
			if(resource!=null){
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"id"))!=null){
					String id = resource.getProperty(model.createProperty(MyTools.getURI()+"id")).getLiteral().getString() ;
					person.setId(id) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"name"))!=null){
					String n = resource.getProperty(model.createProperty(MyTools.getURI()+"name")).getLiteral().getString() ;
					person.setName(n) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"sex"))!=null){
					String sex = resource.getProperty(model.createProperty(MyTools.getURI()+"sex")).getLiteral().getString() ;
					person.setSex(sex) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"birthday"))!=null){
					String birthday = resource.getProperty(model.createProperty(MyTools.getURI()+"birthday")).getLiteral().getString() ;
					person.setBirthday(MyTools.sdf.parse(birthday)) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"nation"))!=null){
					String nation = resource.getProperty(model.createProperty(MyTools.getURI()+"nation")).getLiteral().getString() ;
					person.setNation(nation) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"telephone"))!=null){
					String telephone = resource.getProperty(model.createProperty(MyTools.getURI()+"telephone")).getLiteral().getString() ;
					person.setTelephone(telephone) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"email"))!=null){
					String email = resource.getProperty(model.createProperty(MyTools.getURI()+"email")).getLiteral().getString() ;
					person.setEmail(email) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"remarks"))!=null){
					String remarks = resource.getProperty(model.createProperty(MyTools.getURI()+"remarks")).getLiteral().getString() ;
					person.setRemarks(remarks) ;
				}
				if(resource.getProperty(model.createProperty(MyTools.getURI()+"researchDirections"))!=null){
					String researchDirections = resource.getProperty(model.createProperty(MyTools.getURI()+"researchDirections")).getLiteral().getString() ;
					person.setResearchDirections(researchDirections) ;
				}
			}
		}
		qe.close() ;
		return person ;
	}

}
