package org.ws.dao;

import org.ws.vo.organization.Organization;

public interface OrganizationDao {
	
	public Organization getByName(String name) throws Exception ;
	
}
