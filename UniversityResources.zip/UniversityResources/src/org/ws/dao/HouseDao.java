package org.ws.dao;

import java.util.List;

import org.ws.vo.house.House;

public interface HouseDao {
	/**
	 * ͨ������ƫ������Ȳ�ѯ
	 * @param condition1
	 * @param min1
	 * @param max1
	 * @param condition2
	 * @param min2
	 * @param max2
	 * @param m
	 * @param currentPage
	 * @param lineSize
	 * @return
	 * @throws Exception
	 */
	public List<House> getByUBD(String condition1,float min1, float max1, String condition2,float min2, float max2,
			float m, int currentPage, int lineSize) throws Exception;

}
