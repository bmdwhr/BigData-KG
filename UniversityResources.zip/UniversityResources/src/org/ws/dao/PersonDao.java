package org.ws.dao;

import java.util.List;
import java.util.Map;

import org.ws.vo.person.Person;

public interface PersonDao {
	//�û���¼
	public boolean login(Person person) throws Exception ;
	//ͨ��������ѯƽ��ֵ
	public float getAvgByCondition(String condition) throws Exception ;
	//ͨ���ؼ��ֲ�ѯ
	public List<Person> getByKeywordMap(Map<String,Double> map,int currentPage,int lineSize) throws Exception ;
	
	public Person getByName(String name) throws Exception ;
	
}
