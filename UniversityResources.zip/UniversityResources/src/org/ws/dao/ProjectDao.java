package org.ws.dao;

import java.util.List;

import org.ws.vo.discipline.Project;

public interface ProjectDao {
	
	public List<Project> getByOrganization(String orgname,int currentPage,int lineSize) throws Exception ;
	
}
