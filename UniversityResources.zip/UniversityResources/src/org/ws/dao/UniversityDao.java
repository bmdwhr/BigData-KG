package org.ws.dao;

import java.util.List;
import java.util.Map;

import org.ws.vo.organization.University;

public interface UniversityDao {
	public List<University> getByKeywordMap(Map<String,Double> map,int currentPage,int lineSize) throws Exception ;
	public University getById(String id) throws Exception ;
	
	//ͨ��רҵ���ѧ
	public List<University> getByMajor(String major,int currentPage,int lineSize) throws Exception ;
	//ͨ��������ѯ
	public List<University> getByArea(String area,int currentPage,int lineSize) throws Exception ;

}