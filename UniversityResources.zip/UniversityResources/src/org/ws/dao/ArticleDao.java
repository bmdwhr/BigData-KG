package org.ws.dao;

import java.util.List;
import java.util.Map;

import org.ws.vo.publication.Article;

public interface ArticleDao {

	//ͨ���ؼ��ֲ�ѯ�о���Ʒ
	public List<Article> getByKeywordMap(Map<String,Double> map,int currentPage,int lineSize) throws Exception ;
}
