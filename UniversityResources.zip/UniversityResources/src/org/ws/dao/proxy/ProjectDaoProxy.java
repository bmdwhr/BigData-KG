package org.ws.dao.proxy;

import java.util.List;

import org.ws.conn.OntologyConnection;
import org.ws.dao.ProjectDao;
import org.ws.dao.impl.ProjectDaoImpl;
import org.ws.vo.discipline.Project;

public class ProjectDaoProxy implements ProjectDao {
	
	private ProjectDao projectDao = null;
	private OntologyConnection ontConn = null;

	public ProjectDaoProxy() {
		ontConn = new OntologyConnection();
		projectDao = new ProjectDaoImpl(ontConn.getOntoModel());
	}

	@Override
	public List<Project> getByOrganization(String orgname, int currentPage,
			int lineSize) throws Exception {
		List<Project> all = null ;
		try{
			all = projectDao.getByOrganization(orgname, currentPage, lineSize) ;
		}catch(Exception e){
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all ;
	}
	
	
}
