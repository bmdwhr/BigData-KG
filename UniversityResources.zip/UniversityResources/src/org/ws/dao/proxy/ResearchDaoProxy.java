package org.ws.dao.proxy;

import java.util.List;
import java.util.Map;

import org.ws.conn.OntologyConnection;
import org.ws.dao.ResearchDao;
import org.ws.dao.impl.ResearchDaoImpl;
import org.ws.vo.work.Research;

public class ResearchDaoProxy implements ResearchDao {

	private ResearchDao researchDao;
	private OntologyConnection ontConn;

	public ResearchDaoProxy() {
		ontConn = new OntologyConnection();
		researchDao = new ResearchDaoImpl(ontConn.getOntoModel());
	}

	@Override
	public List<Research> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<Research> all = null;
		try{
			all = researchDao.getByKeywordMap(map, currentPage, lineSize);
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all;
	}

	@Override
	public Research getById(String id) throws Exception {
		Research research = null;
		try{
			research = researchDao.getById(id);
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return research;
	}

	@Override
	public List<Research> getByAuthor(String author, int currentPage,
			int lineSize) throws Exception {
		List<Research> all = null;
		try{
			all = researchDao.getByAuthor(author, currentPage, lineSize);
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all;
	}

}
