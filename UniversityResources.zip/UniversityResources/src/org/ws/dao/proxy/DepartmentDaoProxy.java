package org.ws.dao.proxy;

import java.util.List;
import java.util.Map;

import org.ws.conn.OntologyConnection;
import org.ws.dao.DepartmentDao;
import org.ws.dao.impl.DepartmentDaoImpl;
import org.ws.vo.organization.Department;

public class DepartmentDaoProxy implements DepartmentDao {
	private OntologyConnection ontConn = null ;
	private DepartmentDao departmentDao = null ;
	public DepartmentDaoProxy(){
		ontConn = new OntologyConnection() ;
		departmentDao = new DepartmentDaoImpl(ontConn.getOntoModel()) ;
	}
	@Override
	public List<Department> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<Department> all = null ;
		try{
			all = departmentDao.getByKeywordMap(map, currentPage, lineSize) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all ;
	}
	@Override
	public Department getById(String id) throws Exception {
		Department dept = null ;
		try{
			dept = departmentDao.getById(id) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return dept ;
	}

}
