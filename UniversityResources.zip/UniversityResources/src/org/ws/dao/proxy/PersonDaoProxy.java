package org.ws.dao.proxy;

import java.util.List;
import java.util.Map;

import org.ws.conn.OntologyConnection;
import org.ws.dao.PersonDao;
import org.ws.dao.impl.PersonDaoImpl;
import org.ws.vo.person.Person;


public class PersonDaoProxy implements PersonDao {
	private OntologyConnection ontConn = null ;
	private PersonDao personDao = null ;
	public PersonDaoProxy(){
		ontConn = new OntologyConnection() ;
		personDao = new PersonDaoImpl(ontConn.getOntoModel()) ;
	}
	@Override
	public boolean login(Person person) throws Exception {
		boolean flag = false ;
		try{
			flag = personDao.login(person) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return flag ;
	}
	@Override
	public float getAvgByCondition(String condition) throws Exception {
		float avg = 0f ;
		try{
			avg = personDao.getAvgByCondition(condition) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return avg ;
	}
	@Override
	public List<Person> getByKeywordMap(Map<String,Double> map, int currentPage,
			int lineSize) throws Exception {
		List<Person> all = null ;
		try{
			all = personDao.getByKeywordMap(map, currentPage, lineSize) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all ;
	}
	@Override
	public Person getByName(String name) throws Exception {
		Person person = null ;
		try{
			person = personDao.getByName(name) ;
		}catch(Exception e){
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return person ;
	}
	
}
