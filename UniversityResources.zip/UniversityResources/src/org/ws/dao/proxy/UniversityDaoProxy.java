package org.ws.dao.proxy;

import java.util.List;
import java.util.Map;

import org.ws.conn.OntologyConnection;
import org.ws.dao.UniversityDao;
import org.ws.dao.impl.UniversityDaoImpl;
import org.ws.vo.organization.University;

public class UniversityDaoProxy implements UniversityDao {
	private OntologyConnection ontConn = null ;
	private UniversityDao universityDao = null ;
	
	public UniversityDaoProxy(){
		ontConn = new OntologyConnection() ;
		universityDao = new UniversityDaoImpl(ontConn.getOntoModel()) ;
	}
	@Override
	public List<University> getByKeywordMap(Map<String,Double> map,int currentPage,
			int lineSize) throws Exception {
		List<University> all = null ;
		try{
			all = universityDao.getByKeywordMap(map,currentPage,lineSize) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all ;
	}
	@Override
	public University getById(String id) throws Exception {
		University uni = null ;
		try{
			uni = universityDao.getById(id) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return uni ;
	}
	@Override
	public List<University> getByMajor(String major,int currentPage,int lineSize) throws Exception {
		List<University> all =  null ;
		try{
			all = universityDao.getByMajor(major,currentPage,lineSize) ;
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			ontConn.close() ;
		}
		return all;
	}
	
	@Override
	public List<University> getByArea(String area, int currentPage, int lineSize)
			throws Exception {
		List<University> all =  null ;
		try{
			all = universityDao.getByArea(area, currentPage, lineSize) ;
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			ontConn.close() ;
		}
		return all;
	}
	
}
