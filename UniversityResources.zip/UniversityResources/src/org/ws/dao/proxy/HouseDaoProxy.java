package org.ws.dao.proxy;

import java.util.List;

import org.ws.conn.OntologyConnection;
import org.ws.dao.HouseDao;
import org.ws.dao.impl.HouseDaoImpl;
import org.ws.vo.house.House;

public class HouseDaoProxy implements HouseDao {
	
	private HouseDao houseDao = null;
	private OntologyConnection ontConn = null;

	public HouseDaoProxy() {
		ontConn = new OntologyConnection();
		houseDao = new HouseDaoImpl(ontConn.getOntoModel());
	}

	@Override
	public List<House> getByUBD(String condition1,float min1, float max1, String condition2,float min2, float max2,
			float m, int currentPage, int lineSize) throws Exception {
		List<House> all = null ;
		try{
			all = houseDao.getByUBD(condition1, min1, max1, condition2, min2, max2, m, currentPage, lineSize) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all;
	}
	
}
