package org.ws.dao.proxy;

import java.util.List;
import java.util.Map;

import org.ws.conn.OntologyConnection;
import org.ws.dao.ArticleDao;
import org.ws.dao.impl.ArticleDaoImpl;
import org.ws.vo.publication.Article;

public class ArticleDaoProxy implements ArticleDao {

	private ArticleDao articleDao = null;
	private OntologyConnection ontConn = null;

	public ArticleDaoProxy() {
		ontConn = new OntologyConnection();
		articleDao = new ArticleDaoImpl(ontConn.getOntoModel());
	}

	@Override
	public List<Article> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<Article> all = null;
		try{
			all = articleDao.getByKeywordMap(map, currentPage, lineSize);
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}		
		return all;
	}

}
