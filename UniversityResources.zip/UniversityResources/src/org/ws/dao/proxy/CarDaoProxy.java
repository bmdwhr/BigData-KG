package org.ws.dao.proxy;

import java.util.List;

import org.ws.conn.OntologyConnection;
import org.ws.dao.CarDao;
import org.ws.dao.impl.CarDaoImpl;
import org.ws.vo.car.Car;

public class CarDaoProxy implements CarDao {
	
	private CarDao carDao = null;
	private OntologyConnection ontConn = null;

	public CarDaoProxy() {
		ontConn = new OntologyConnection();
		carDao = new CarDaoImpl(ontConn.getOntoModel());
	}

	@Override
	public List<Car> getByBSD(float min, float max, String brand,
			int currentPage, int lineSize) throws Exception {
		List<Car> all = null ;
		try{
			all = carDao.getByBSD(min, max, brand, currentPage, lineSize) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all;
	}
	
}
