package org.ws.dao.proxy;

import org.ws.conn.OntologyConnection;
import org.ws.dao.OrganizationDao;
import org.ws.dao.impl.OrganizationDaoImpl;
import org.ws.vo.organization.Organization;

public class OrganizationDaoProxy implements OrganizationDao {

	private OrganizationDao orgDao = null;
	private OntologyConnection ontConn = null;

	public OrganizationDaoProxy() {
		ontConn = new OntologyConnection();
		orgDao = new OrganizationDaoImpl(ontConn.getOntoModel());
	}

	@Override
	public Organization getByName(String name) throws Exception {
		Organization org = null ;
		try{
			org = orgDao.getByName(name) ;
		}catch(Exception e){
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return org ;
	}

}
