package org.ws.dao.proxy;

import java.util.List;
import java.util.Map;

import org.ws.conn.OntologyConnection;
import org.ws.dao.FacultyDao;
import org.ws.dao.impl.FacultyDaoImpl;
import org.ws.vo.person.Faculty;

public class FacultyDaoProxy implements FacultyDao {
	private FacultyDao facultyDao = null;
	private OntologyConnection ontConn = null;

	public FacultyDaoProxy() {
		ontConn = new OntologyConnection();
		facultyDao = new FacultyDaoImpl(ontConn.getOntoModel());
	}
	
	@Override
	public int getCountByConditionRange(String condition, float min, float max,
			int flag) throws Exception {
		int count = 0 ;
		try{
			count = facultyDao.getCountByConditionRange(condition, min, max, flag) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return count ;
	}

	@Override
	public List<Faculty> getByConditionRange(String condition, float min,
			float max, int flag, int currentPage, int lineSize)
			throws Exception {
		List<Faculty> all = null;
		try{
			all = facultyDao.getByConditionRange(condition, min, max, flag,currentPage, lineSize);
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all;
	}
	
	@Override
	public List<Faculty> getByKeyword(String keyword,
			int currentPage, int lineSize) throws Exception {
		List<Faculty> all = null;
		try{
			all = facultyDao.getByKeyword(keyword, currentPage, lineSize);
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all;
	}

	@Override
	public List<Faculty> getByKeywordMap(Map<String, Double> map,
			int currentPage, int lineSize) throws Exception {
		List<Faculty> all = null;
		try{
			all = facultyDao.getByKeywordMap(map, currentPage, lineSize);
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all;
	}

	@Override
	public List<Faculty> getByBSD(String condition1, float min1, float max1,float m1,
			int flag1, String condition2, float min2, float max2, float m2,int flag2,
			int currentPage, int lineSize) throws Exception {
		List<Faculty> all = null;
		try{
			all = facultyDao.getByBSD(condition1, min1, max1,m1, flag1, condition2, min2, max2, m2,flag2, currentPage, lineSize) ;
		}catch (Exception e) {
			e.printStackTrace() ;
		}finally{
			ontConn.close() ;
		}
		return all;
	}
	
}
