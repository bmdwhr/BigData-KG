package org.ws.util;

import java.util.Map;
import java.util.TreeMap;

public class PowerTable {
	public static Map<String,PowerValue> getPowerTable(){
		Map<String,PowerValue> map = new TreeMap<String,PowerValue>() ;
		map.put("absolutely high",new PowerValue(1.0f,1.0f)) ;
		map.put("extremely high",new PowerValue(0.9f,1.0f)) ;
		map.put("very high",new PowerValue(0.81f,0.95f)) ;
		map.put("high",new PowerValue(0.71f,0.85f)) ;
		map.put("fairly high",new PowerValue(0.62f,0.76f)) ;
		map.put("somewhat high",new PowerValue(0.52f,0.66f)) ;
		map.put("medium",new PowerValue(0.43f,0.57f)) ;
		map.put("somewhat low",new PowerValue(0.33f,0.47f)) ;
		map.put("fairly low",new PowerValue(0.24f,0.38f)) ;
		map.put("low",new PowerValue(0.14f,0.28f)) ;
		map.put("very low",new PowerValue(0.05f,0.19f)) ;
		map.put("extremely low",new PowerValue(0.0f,0.09f)) ;
		map.put("absolutely low",new PowerValue(0.0f,0.0f)) ;
		return map ;
	}
	

}
