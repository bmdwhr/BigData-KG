/*
 * Copyright (C) 2008 SKLSDE(State Key Laboratory of Software Development and Environment, Beihang University)., All Rights Reserved.
 */
package org.ws.util;

import java.io.BufferedReader;
import java.io.FileReader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ��ԭ
 * 
 * @author Yingqiang Wu
 * @version 1.0
 */
public class Primitive {
	private String primitive;
	private int id;
	private int parentId;

	public static Map<Integer, Primitive> ALLPRIMITIVES = new HashMap<Integer, Primitive>();

	public static Map<String, Integer> PRIMITIVESID = new HashMap<String, Integer>();

	/**
	 * ������ԭ�ļ���
	 */
	static {
		String line = null;
		try {
			BufferedReader reader = new BufferedReader(new FileReader(
					"dict/WHOLE.DAT"));
			line = reader.readLine();
			while (line != null) {
				line = line.trim().replaceAll("\\s+", " ");
				String[] strs = line.split(" ");
				int id = Integer.parseInt(strs[0]);
				String[] words = strs[1].split("\\|");
				String english = words[0];
				String chinese = words[1];
				int parentId = Integer.parseInt(strs[2]);
				ALLPRIMITIVES.put(id, new Primitive(id, chinese, parentId));
				// ALLPRIMITIVES.put(id, new Primitive(id, english, parentId));
				PRIMITIVESID.put(chinese, id);
				PRIMITIVESID.put(english, id);
				line = reader.readLine();
			}
		} catch (Exception e) {
			System.out.println(line);
			e.printStackTrace();
		}
	}

	/**
	 * Creates a new Primitive object.
	 * 
	 * @param id
	 * @param primitive
	 * @param parentId
	 */
	public Primitive(int id, String primitive, int parentId) {
		this.id = id;
		this.parentId = parentId;
		this.primitive = primitive;
	}

	/**
	 * 
	 * @return �Ƿ��Ǹ�Ԫ��
	 */
	public boolean isTop() {
		return id == parentId;
	}

	/**
	 * ���һ����ԭ�����и���ԭ��ֱ������λ�á�
	 * 
	 * @param primitive
	 * @return ������ҵ���ԭû�в��ҵ����򷵻�һ����list
	 */
	public static List<Integer> getParents(String primitive) {
		List<Integer> list = new ArrayList<Integer>();
		Integer id = PRIMITIVESID.get(primitive);
		if (id != null) {
			Primitive parent = ALLPRIMITIVES.get(id);
			list.add(id);
			while (!parent.isTop()) {
				list.add(parent.getParentId());
				parent = ALLPRIMITIVES.get(parent.getParentId());
			}
		}
		return list;
	}

	/**
	 * �ж��Ƿ�����ԭ
	 * 
	 * @param primitive
	 * @return 
	 */
	public static boolean isPrimitive(String primitive) {
		return PRIMITIVESID.containsKey(primitive);
	}

	public String getPrimitive() {
		return primitive;
	}

	public void setPrimitive(String primitive) {
		this.primitive = primitive;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
}
