package org.ws.util;

public class PowerValue {
	
	private float leftLimit ;
	private float rightLimit ;
	//���췽��
	public PowerValue(){
		this.setLeftLimit(0.0f);
		this.setRightLimit(1.0f);
	}
	public PowerValue(float leftLimit,float rightLimit){
		if(leftLimit>rightLimit){
			this.setLeftLimit(rightLimit);
			this.setRightLimit(leftLimit);
		}else{
			this.setLeftLimit(leftLimit);
			this.setRightLimit(rightLimit);
		}	
	}
	//����Ȩֵ
	public void setPowerValue(float leftLimit,float rightLimit){
		if(leftLimit>rightLimit){
			this.setLeftLimit(rightLimit);
			this.setRightLimit(leftLimit);
		}else{
			this.setLeftLimit(leftLimit);
			this.setRightLimit(rightLimit);
		}	
	}

	public float getLeftLimit() {
		return leftLimit;
	}
	public void setLeftLimit(float leftLimit) {
		this.leftLimit = leftLimit;
	}
	public float getRightLimit() {
		return rightLimit;
	}
	public void setRightLimit(float rightLimit) {
		this.rightLimit = rightLimit;
	}
	@Override
	public String toString() {
		return " [" + leftLimit + ", "
				+ rightLimit + "]";
	}

}
