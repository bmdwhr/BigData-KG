package org.ws.view;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.ws.factory.DaoFactory;
import org.ws.tools.ImagePanel;
import org.ws.tools.MyTools;
import org.ws.util.MD5Code;
import org.ws.vo.person.Person;


public class Login implements ActionListener{
	ImagePanel imagePanel ;
	Image image ;
	JFrame frame ;
    JLabel label1,label2 ;
    JButton button1,button2 ;
    JTextField jtf ;
    JPasswordField jpf ;
    int width = MyTools.width ;
	int height = MyTools.height ;
	public Login(){
		this.frame = new JFrame() ;
		frame.setLayout(null) ;
		frame.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(1) ;
			}
		}) ;
		try {
			image = ImageIO.read(new File("image"+File.separator+"login.jpg")) ;
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		imagePanel = new ImagePanel(image,400,300) ;//���ñ���ͼƬ
		imagePanel.setLayout(null) ;
		frame.setResizable(false) ;//��������
		this.label1 = new JLabel("�û���:") ;
		label1.setFont(MyTools.font1) ;
		label1.setBounds(120,90,55,20) ;
		this.jtf = new JTextField(12) ;
		jtf.setBorder(BorderFactory.createLoweredBevelBorder()) ;//�����°�
		jtf.setBounds(175,90,100,20) ;
		jtf.setFont(MyTools.font1) ;
		imagePanel.add(label1) ;
		imagePanel.add(jtf) ;
		
		this.label2 = new JLabel("��  ��:") ;
		label2.setBounds(120,130, 55, 20) ;
		label2.setFont(MyTools.font1) ;
		this.jpf = new JPasswordField(12) ;
		jpf.setBorder(BorderFactory.createLoweredBevelBorder()) ;
		jpf.setBounds(175,130,100,20) ;
		jpf.setFont(MyTools.font1) ;
		jpf.setEchoChar('*') ;
		imagePanel.add(label2) ;
		imagePanel.add(jpf) ;
		this.button1 = new JButton("ȷ��") ;
		button1.setCursor(MyTools.cursor) ;
		this.frame.getRootPane().setDefaultButton(button1) ;//��ΪĬ��
		button1.addActionListener(this) ;
		button1.setBounds(120,170,60,20) ;
		this.button2 = new JButton("ȡ��") ;
		button2.setCursor(MyTools.cursor) ;
		button2.addActionListener(this) ;
		button2.setBounds(215,170,60,20) ;
		imagePanel.add(button1) ;
		imagePanel.add(button2) ;
		frame.add(imagePanel) ;
		frame.setTitle("��У��Դ���ܹ���ϵͳ ") ;
		frame.setSize(400,300) ;
		frame.setLocation(width/2-200,height/2-150) ;
		frame.setVisible(true) ;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.button1){
			boolean flag = false ;
			String userid = this.jtf.getText().trim() ;
			String userpwd = new String(this.jpf.getPassword()) ;
			Person person = new Person() ;
			person.setUserid(userid) ;
			person.setUserpwd(new MD5Code().getMD5ofStr(userpwd)) ;
			try {
				flag = DaoFactory.getPersonDaoInstance().login(person) ;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			if(flag){
					new Window() ;
					frame.dispose() ;	
			}else{
				JOptionPane.showMessageDialog(frame,"�û������������") ; 	
			}
		}else if(e.getSource() == this.button2){
			this.frame.dispose() ;
		}
		
	}
}
