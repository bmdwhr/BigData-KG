package org.ws.view.research;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.WordSimilarity;
import org.ws.view.research.show.PublicationBarChart3D;
import org.ws.view.research.show.ShowResearch;
import org.ws.vo.publication.Article;
import org.ws.vo.work.Research;

public class ThemeResearch extends MouseAdapter implements ActionListener {
	private JScrollPane scrollPane_theme;// ������������
	private JScrollPane scrollPane_table;// �������
	private JTable table;
	private String[] titles = { "���", "��������", "����" };
	private DefaultTableModel tableModel;
	private JPanel panel, researchPane;
	private Box box;// �м����
	private JLabel label;// ����
	private JLabel label_NO1;// ������
	private JLabel label_NO2;// ���Ľ϶�Ļ���
	private JLabel label_NO3;// ���Ľ϶������
	private JLabel label_NO4;// ����
	private JTextField textField;
	private JButton button;
	private String option;
	private List<Article> articles;// ����
	private List<Research> researchs;// ��Ʒ
	private JFrame frame;
	private ShowResearch show;// ��������ϸ��Ϣ����

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ThemeResearch window = new ThemeResearch();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public ThemeResearch() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame("�������");
		frame.add(this.getJScrollPane());
		this.label_NO1 = new JLabel("һ��������");
		label_NO1.setFont(MyTools.font3);
		this.label_NO2 = new JLabel("�������Ľ϶���ڿ�");
		label_NO2.setFont(MyTools.font3);
		this.label_NO3 = new JLabel("�������Ľ϶������");
		label_NO3.setFont(MyTools.font3);
		this.label_NO4 = new JLabel("�ġ�����");
		label_NO4.setFont(MyTools.font3);
		frame.setBounds(MyTools.width / 2 - 512, MyTools.height / 2 - 384,
				1024, 738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		show = new ShowResearch();
	}

	public JScrollPane getJScrollPane() {
		panel = new JPanel(new BorderLayout());
		researchPane = new JPanel(new FlowLayout(FlowLayout.CENTER));// ������ѯ���
		label = new JLabel("��   �⣺");
		label.setFont(MyTools.font2);
		researchPane.add(label);
		textField = new JTextField(20);
		researchPane.add(textField);
		button = new JButton("���ɱ���");
		button.addActionListener(this);
		button.setCursor(MyTools.cursor);
		researchPane.add(button);
		panel.add(researchPane, BorderLayout.NORTH);
		box = Box.createVerticalBox();// �м��ͼ��弰����
		panel.add(box, BorderLayout.CENTER);
		scrollPane_theme = new JScrollPane(panel,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		return scrollPane_theme;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.button) {
			int currentPage = 1;
			int lineSize = 10;
			if (this.textField.getText() == null
					|| "".equals(this.textField.getText())) {
				JOptionPane.showMessageDialog(frame, "����Ϊ�գ�");
				return;
			}
			this.option = this.textField.getText().trim();
			Map<String, Double> map = WordSimilarity.getWordsBySimilarity(
					option, MyTools.SIMILARITY);
			try {
				this.articles = DaoFactory.getArticleDaoInstance()
						.getByKeywordMap(map, currentPage, lineSize);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			if (articles.size() <= 0) {
				JOptionPane.showMessageDialog(frame, "����ؼ�¼��");
				return;
			}
			box.removeAll();// �Ƴ�ȫ��
			this.box.add(this.label_NO1);
			this.box.add(new JLabel("�ؼ��֣�" + option));
			StringBuffer relatedkey = new StringBuffer();
			for (String key : map.keySet()) {
				relatedkey.append(key + "  ");
			}
			String[] str = relatedkey.toString().split("  ");
			if (str.length > 10) {
				// ��ش�̫��
				relatedkey = new StringBuffer();
				for (int i = 0; i < 10; i++) {
					relatedkey.append(str[i] + "  ");
				}
			}
			this.box.add(new JLabel("��شʣ�" + relatedkey.toString()));
			box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			this.box.add(this.label_NO2);
			this.box.add(new PublicationBarChart3D().getChartPanel(articles));
			box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			this.box.add(this.label_NO3);
			// ����
			this.table = new JTable() {
				private static final long serialVersionUID = 1L;
				@Override
				public boolean isCellEditable(int row, int column) {
					return false;
				}
			};
			table.addMouseListener(this);
			scrollPane_table = new JScrollPane(table,
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			this.box.add(scrollPane_table);
			this.tableModel = new DefaultTableModel(null, this.titles);
			try {
				this.researchs = DaoFactory.getResearchDaoInstance()
						.getByKeywordMap(map, currentPage, lineSize);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			Iterator<Research> iter = researchs.iterator();
			while (iter.hasNext()) {
				Research research = iter.next();
				Object[] obj = new Object[3];
				obj[0] = research.getId();
				obj[1] = research.getAuthor();
				obj[2] = research.getAmount();
				tableModel.addRow(obj);
			}
			table.setModel(tableModel);
			box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			//this.box.add(this.label_NO4);//����
			box.repaint();// �ػ�
			box.validate();// ��Ч
			// this.scrollPane_theme.validate() ;
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			String id = (String) table.getValueAt(table.getSelectedRow(), 0);
			Research research = null;
			try {
				research = DaoFactory.getResearchDaoInstance().getById(id);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			show.getTopicLabel().setText(research.getTopic());// ���ı���
			show.getContentTextArea().setText(research.getContent());// ��������
			show.getFrame().setVisible(true);
		}
	}
}
