package org.ws.view.research.show;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.ws.tools.MyTools;

public class ShowResearch {

	private JFrame frame ;
	private JPanel panel ;
	private JPanel topPanel ;//�������
	private JPanel centerPanel ;//�м����
	private JScrollPane jsp ;//�м�����������
	private JLabel topicLabel ;//����
	private JTextArea contentTextArea ;//����
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowResearch window = new ShowResearch();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public ShowResearch() {
		frame = new JFrame("��ϸ��Ϣ");
		frame.add(this.getPanel()) ;
		frame.setBounds(MyTools.width/2-350,MyTools.height/2-250,700,500);
		frame.add(this.getPanel(),BorderLayout.CENTER) ;
		frame.setResizable(false) ;//���ڴ�С���ɱ�
	}
	public JPanel getPanel(){
		panel = new JPanel(new BorderLayout()) ;
		topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)) ;
		topicLabel = new JLabel("����") ;
		topPanel.add(topicLabel) ;
		panel.add(topPanel,BorderLayout.NORTH) ;
		
		centerPanel = new JPanel() ;
		contentTextArea = new JTextArea("����",23,60) ;
		contentTextArea.setEditable(false) ;//���ɱ༭
		contentTextArea.setLineWrap(true) ;//���û���
		centerPanel.add(contentTextArea) ;
		jsp = new JScrollPane(centerPanel,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED) ;
		panel.add(jsp,BorderLayout.CENTER) ;
		return panel ;
	}
	
	
	
	
	public JFrame getFrame() {
		return frame;
	}
	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
	public JLabel getTopicLabel() {
		return topicLabel;
	}
	public void setTopicLabel(JLabel topicLabel) {
		this.topicLabel = topicLabel;
	}
	public JTextArea getContentTextArea() {
		return contentTextArea;
	}
	public void setContentTextArea(JTextArea contentTextArea) {
		this.contentTextArea = contentTextArea;
	}
}
