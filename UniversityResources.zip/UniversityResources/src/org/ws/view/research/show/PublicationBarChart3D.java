package org.ws.view.research.show;

import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.ws.tools.MyTools;
import org.ws.vo.publication.Publication;

@SuppressWarnings("unchecked")
public class PublicationBarChart3D {
	public ChartPanel getChartPanel(List list) {
		ChartPanel chartPanel = new ChartPanel(createJFreeChart(createCategorydataset(list))) ;
		return chartPanel ;
	}
	private CategoryDataset createCategorydataset(List<Publication> list){
		DefaultCategoryDataset dataset = new DefaultCategoryDataset() ;
		for(int i=0;i<list.size();i++){
			dataset.addValue(list.get(i).getAmount(),"",list.get(i).getPublisher()) ;
		}
		return dataset ;
	}
	private JFreeChart createJFreeChart(CategoryDataset dataset){
		ChartFactory.setChartTheme(MyTools.createStandardChartTheme()) ;
		JFreeChart chart = ChartFactory.createBarChart3D("���Ľ϶���ڿ�","������","����", dataset,PlotOrientation.HORIZONTAL,false,true,false) ;
		return chart ;
	}

}
