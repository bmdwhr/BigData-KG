package org.ws.view.research;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.vo.discipline.Project;
import org.ws.vo.organization.Organization;

public class OrganizationResearch implements ActionListener{
	public  JScrollPane scrollPane_theme ;// ������������
	private JPanel panel,researchPane;
	private Box box;// �м����
	private JLabel label ;
	private JLabel label_NO1;// �������
	private JLabel label_NO2;// �����е����ҿƼ���Ŀ���
	private JTextField textField ;
	private JButton button ;
	private JFrame frame;
	private String option;
	private Organization org = null ;
	private List<Project> all = null ;
	private int currentPage = 1 ;
	private int lineSize = 10 ;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OrganizationResearch window = new OrganizationResearch();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public OrganizationResearch() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame("��������");
		frame.add(this.getJScrollPane()) ;
		this.label_NO1 = new JLabel("һ���������");
		label_NO1.setFont(MyTools.font3);
		this.label_NO2 = new JLabel("���������е����ҿƼ���Ŀ���");
		label_NO2.setFont(MyTools.font3);
		frame.setBounds(MyTools.width/2-512,MyTools.height/2-384,1024,738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public JScrollPane getJScrollPane(){
		panel = new JPanel(new BorderLayout());
		researchPane = new JPanel(new FlowLayout(FlowLayout.CENTER));// ������ѯ���
		label = new JLabel("��   ����");
		label.setFont(MyTools.font2);
		researchPane.add(label);
		textField = new JTextField(20);
		researchPane.add(textField);
		button = new JButton("���ɱ���");
		button.setCursor(MyTools.cursor);
		button.addActionListener(this) ;
		researchPane.add(button);
		panel.add(researchPane, BorderLayout.NORTH);
		box = Box.createVerticalBox();// �м��ͼ��弰����
		panel.add(box, BorderLayout.CENTER);
		scrollPane_theme = new JScrollPane(panel,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		return scrollPane_theme;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.button) {
			if (this.textField.getText() == null
					|| "".equals(this.textField.getText())) {
				JOptionPane.showMessageDialog(frame, "����Ϊ�գ�");
				return;
			}
			this.option = this.textField.getText().trim();
			box.removeAll();// �Ƴ�ȫ��
			this.box.add(this.label_NO1);
			try {
				org = DaoFactory.getOrganizationDaoInstance().getByName(option) ;
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			if(org == null){
				JOptionPane.showMessageDialog(frame, "���߹ؼ�¼��");
				return;
			}
			this.box.add(new JLabel("�������ƣ�" + org.getName()));
			this.box.add(new JLabel("������飺" + org.getIntroduction()));
			box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			this.box.add(this.label_NO2);
			try {
				all = DaoFactory.getProjectDaoInstance().getByOrganization(option, currentPage, lineSize) ;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			Iterator<Project> iter = all.iterator() ;
			for(int i=1;iter.hasNext();i++){
				Project pro = iter.next() ;
				this.box.add(new JLabel(i+"��" + pro.getName()));
			}
			box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			//this.box.add(this.label_NO4);//����
			box.repaint();// �ػ�
			box.validate();// ��Ч
			// this.scrollPane_theme.validate() ;
		}
	}

}
