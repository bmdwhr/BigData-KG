package org.ws.view.research;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import org.ws.tools.MyTools;

public class PersonQuery {
    public JScrollPane teacherPanel ;
	private JFrame frame;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PersonQuery window = new PersonQuery();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public PersonQuery() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame("�����ѯ");
		frame.setBounds(MyTools.width/2-512,MyTools.height/2-384,1024,738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public JScrollPane getJScrollPane(){
		this.teacherPanel = new JScrollPane() ;
		return this.teacherPanel ;
	}

}
