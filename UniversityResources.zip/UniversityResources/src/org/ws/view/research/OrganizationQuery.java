package org.ws.view.research;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

public class OrganizationQuery {
    public JScrollPane teacherPanel ;
	private JFrame frame;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OrganizationQuery window = new OrganizationQuery();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public OrganizationQuery() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame("������ѯ");
		frame.setBounds(100,100,450,300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public JScrollPane getJScrollPane(){
		this.teacherPanel = new JScrollPane() ;
		return this.teacherPanel ;
	}

}
