package org.ws.view.research;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.view.research.show.ShowResearch;
import org.ws.vo.person.Person;
import org.ws.vo.work.Research;

public class PersonResearch extends MouseAdapter implements ActionListener {
	private JScrollPane scrollPane_theme;// ������������
	private JScrollPane scrollPane_table;// �������
	private JTable table;
	private String[] titles = { "���", "��Ʒ����", "��������" };
	private DefaultTableModel tableModel;
	private JPanel panel, researchPane;
	private Box box;// �м����
	private JLabel label;// ����
	private JLabel label_NO1;// ������
	private JLabel label_NO2;// �����϶������
	private JTextField textField;
	private JButton button;
	private String option;
	private List<Research> researchs;// ��Ʒ
	private JFrame frame;
	private ShowResearch show;// ��������ϸ��Ϣ����
	private Person person = null ;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PersonResearch window = new PersonResearch();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public PersonResearch() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame("�������");
		frame.add(this.getJScrollPane());
		this.label_NO1 = new JLabel("һ��������");
		label_NO1.setFont(MyTools.font3);
		this.label_NO2 = new JLabel("���������϶������");
		label_NO2.setFont(MyTools.font3);
		frame.setBounds(MyTools.width / 2 - 512, MyTools.height / 2 - 384,
				1024, 738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		show = new ShowResearch();
	}

	public JScrollPane getJScrollPane() {
		panel = new JPanel(new BorderLayout());
		researchPane = new JPanel(new FlowLayout(FlowLayout.CENTER));// ������ѯ���
		label = new JLabel("��   �");
		label.setFont(MyTools.font2);
		researchPane.add(label);
		textField = new JTextField(20);
		researchPane.add(textField);
		button = new JButton("���ɱ���");
		button.addActionListener(this);
		button.setCursor(MyTools.cursor);
		researchPane.add(button);
		panel.add(researchPane, BorderLayout.NORTH);
		box = Box.createVerticalBox();// �м��ͼ��弰����
		panel.add(box, BorderLayout.CENTER);
		scrollPane_theme = new JScrollPane(panel,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		return scrollPane_theme;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.button) {
			int currentPage = 1;
			int lineSize = 10;
			if (this.textField.getText() == null
					|| "".equals(this.textField.getText())) {
				JOptionPane.showMessageDialog(frame, "����Ϊ�գ�");
				return;
			}
			this.option = this.textField.getText().trim();
			box.removeAll();// �Ƴ�ȫ��
			this.box.add(this.label_NO1);
			try {
				person = DaoFactory.getPersonDaoInstance().getByName(option) ;
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			if(person == null){
				JOptionPane.showMessageDialog(frame, "���߹ؼ�¼��");
				return;
			}
			this.box.add(new JLabel("������" + person.getName()));
			this.box.add(new JLabel("�о�����" + person.getResearchDirections()));
			box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			this.box.add(this.label_NO2);
			// ����
			this.table = new JTable() {
				private static final long serialVersionUID = 1L;
				@Override
				public boolean isCellEditable(int row, int column) {
					return false;
				}
			};
			table.addMouseListener(this);
			scrollPane_table = new JScrollPane(table,
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			this.box.add(scrollPane_table);
			this.tableModel = new DefaultTableModel(null, this.titles);
			try {
				researchs = DaoFactory.getResearchDaoInstance().getByAuthor(option,currentPage, lineSize) ;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			Iterator<Research> iter = researchs.iterator();
			while (iter.hasNext()) {
				Research research = iter.next();
				Object[] obj = new Object[3];
				obj[0] = research.getId();
				obj[1] = research.getTopic();
				obj[2] = research.getAmount();
				tableModel.addRow(obj);
			}
			table.setModel(tableModel);
			box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			//this.box.add(this.label_NO2);
			//this.box.add(this.label_NO4);//����
			box.repaint();// �ػ�
			box.validate();// ��Ч
			// this.scrollPane_theme.validate() ;
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			String id = (String) table.getValueAt(table.getSelectedRow(), 0);
			Research research = null;
			try {
				research = DaoFactory.getResearchDaoInstance().getById(id);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			show.getTopicLabel().setText(research.getTopic());// ���ı���
			show.getContentTextArea().setText(research.getContent());// ��������
			show.getFrame().setVisible(true);
		}
	}
}
