package org.ws.view;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import org.ws.conn.OntologyConnection;
import org.ws.tools.ImagePanel;
import org.ws.tools.MyTools;

public class Loading {
    private Image image ;
    private ImagePanel imagePanel ;
    private JFrame frame;
	public static void main(String[] args) {
		Loading load = new Loading() ;
		load.frame.setVisible(true) ;
		new OntologyConnection().close() ;//�����ڴ�
		try {
			Thread.sleep(3000) ;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		new Login() ;
		load.frame.dispose() ;	
	}
	
	public Loading() {
		frame = new JFrame();
		try {
			image = ImageIO.read(new File("image"+File.separator+"load.png")) ;
		} catch (IOException e) {
			e.printStackTrace();
		}
		imagePanel = new ImagePanel(image,400,300) ;
		frame.add(imagePanel) ;
		frame.setBounds(MyTools.width/2-200,MyTools.height/2-150,400,300);
		frame.setUndecorated(true);//��ʹ�����¿�
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
