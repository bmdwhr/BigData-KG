package org.ws.view.query;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.WordSimilarity;
import org.ws.view.query.show.ShowQuery;
import org.ws.vo.organization.Department;

public class DepartmentQuery extends MouseAdapter implements ActionListener {

	private JPanel panel;// �����
	private JPanel top;
	private JLabel label;// ���Ų�ѯ��
	private JTextField textField;
	private JButton button;
	private Box box;// �����ʾ
	private JScrollPane jsp;// �����������
	private JFrame frame;
	private JTable table;
	private String[] titles = { "���", "����" };
	private DefaultTableModel tableModel;
	private ShowQuery show;// ��������ϸ��Ϣ����

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DepartmentQuery window = new DepartmentQuery();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public DepartmentQuery() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame("���Ų�ѯ");
		frame.add(this.getJPanel());
		frame.setBounds(MyTools.width / 2 - 512, MyTools.height / 2 - 384,
				1024, 738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		show = new ShowQuery();
	}

	public JPanel getJPanel() {
		panel = new JPanel(new BorderLayout());
		top = new JPanel(new FlowLayout(FlowLayout.CENTER));// ����
		label = new JLabel("��  �ţ�");
		label.setFont(MyTools.font2);
		top.add(label);
		textField = new JTextField(20);
		top.add(textField);
		button = new JButton("��ѯ");
		button.addActionListener(this);
		button.setCursor(MyTools.cursor);
		top.add(button);
		panel.add(top, BorderLayout.NORTH);

		box = Box.createVerticalBox();
		panel.add(box, BorderLayout.CENTER);
		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		tableModel = new DefaultTableModel(null, this.titles);
		if (e.getSource() == button) {
			int currentPage = 1;
			int lineSize = 10;
			if (this.textField.getText() == null
					|| "".equals(this.textField.getText())) {
				JOptionPane.showMessageDialog(frame, "����Ϊ�գ�");
				return;
			}
			String keyword = this.textField.getText();
			Map<String, Double> map = WordSimilarity.getWordsBySimilarity(
					keyword, MyTools.SIMILARITY);
			List<Department> all = null;
			try {
				all = DaoFactory.getDepartmentDaoInstance().getByKeywordMap(
						map, currentPage, lineSize);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			if (all.size() <= 0) {
				JOptionPane.showMessageDialog(frame, "����ؼ�¼��");
				return;
			}
			box.removeAll();// �Ƴ�ȫ��
			box.add(new JLabel("�ؼ��֣�" + keyword));
			StringBuffer relatedkey = new StringBuffer();
			for (String key : map.keySet()) {
				relatedkey.append(key + "  ");
			}
			String[] str = relatedkey.toString().split("  ");
			if (str.length > 10) {
				// ��ش�̫��
				relatedkey = new StringBuffer();
				for (int i = 0; i < 10; i++) {
					relatedkey.append(str[i] + "  ");
				}
			}
			this.box.add(new JLabel("��شʣ�" + relatedkey.toString()));
			box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			// ����
			table = new JTable() {
				private static final long serialVersionUID = 1L;
				public boolean isCellEditable(int row, int column) {
					return false;
				}
			};
			table.addMouseListener(this);
			jsp = new JScrollPane(table,
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			box.add(jsp);
			Iterator<Department> iter = all.iterator();
			while (iter.hasNext()) {
				Department dept = iter.next();
				Object[] obj = new Object[2];
				obj[0] = dept.getId();
				obj[1] = dept.getName();
				tableModel.addRow(obj);
			}
			table.setModel(tableModel);
			box.repaint() ;//�ػ�
			box.validate();// ��Ч
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			String id = (String) table.getValueAt(table.getSelectedRow(), 0);
			Department dept = null;
			try {
				dept = DaoFactory.getDepartmentDaoInstance().getById(id);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			show.getTopicLabel().setText(dept.getName());
			show.getContentTextArea().setText(dept.getIntroduction());
			show.getFrame().setVisible(true);
		}
	}

}
