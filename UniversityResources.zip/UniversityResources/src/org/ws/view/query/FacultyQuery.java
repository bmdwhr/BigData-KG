package org.ws.view.query;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.PowerTable;
import org.ws.util.PowerValue;
import org.ws.util.WordSimilarity;
import org.ws.vo.person.Faculty;

public class FacultyQuery extends MouseAdapter implements ActionListener,ItemListener {
	private DefaultTableModel tableModel ;
	private List<Faculty> all  ;
	private Object[] userInfo ;
	private String option ;
	private String[] titles={"����","�Ա�","��������","����","�绰","Email","������","����","������λ","רҵ�����ογ�","רҵ����ְ��","��ע"} ;
	private long runTime = 0 ;
	private JLabel label = null ;
	private JFrame frame;
	private JPanel choosePanel,panel,cardLayoutPanel,topPanel,topHighPanel,topCommonPanel,bottomPanel  ;
	private JComboBox chooseComboBox,optionComboBox,conditionComboBox01,conditionComboBox02 ;
	private JButton highQueryButton,commonQueryButton ;
	private JTable table ;
	private CardLayout cardLayout = null ;
	private JTextField text ;
	private JTabbedPane tabbedPane ;
	private float minValue = 0f ;
	private float maxValue = 0f;
	private int size = -1  ;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FacultyQuery window = new FacultyQuery();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public FacultyQuery() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame("��ʦ������Ϣ��ѯ");
		frame.setResizable(false) ;
		frame.setBounds(MyTools.width/2-512,MyTools.height/2-384,1024,738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tabbedPane = new JTabbedPane() ;
		tabbedPane.add("�߼���ѯ",this.getPanel()) ;
		frame.getContentPane().add(tabbedPane) ;
	}
    public JPanel getPanel(){
    	panel = new JPanel(new BorderLayout()) ;
    	//����
    	topPanel = new JPanel(new BorderLayout()) ;//�������
    	choosePanel = new JPanel() ;//�����ұ�ѡ�����
    	chooseComboBox = new JComboBox() ;
    	chooseComboBox.setCursor(MyTools.cursor) ;
    	chooseComboBox.addItem("��ͨ��ѯ") ;
    	chooseComboBox.addItem("�߼���ѯ") ;
    	chooseComboBox.addItemListener(this) ;
    	choosePanel.add(chooseComboBox) ;
    	topPanel.add(choosePanel,BorderLayout.EAST) ;
    	cardLayout = new CardLayout() ;//�����м��л������
    	cardLayoutPanel = new JPanel(cardLayout) ;
    	     //��ͨ��ѯ
    	topCommonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER,40,30)) ;
    	text = new JTextField(30) ;
    	commonQueryButton = new JButton("��ѯ") ;
    	commonQueryButton.setCursor(MyTools.cursor) ;
    	commonQueryButton.addActionListener(this) ;
    	topCommonPanel.add(text) ;
    	topCommonPanel.add(commonQueryButton) ;
    	cardLayoutPanel.add(topCommonPanel,"topCommonPanel") ;
    	     //�߼���ѯ
    	topHighPanel = new JPanel(new FlowLayout(FlowLayout.CENTER,60,10)) ;
    	String[] options= {"������","����"} ;
    	optionComboBox = new JComboBox(options) ;
    	optionComboBox.setCursor(MyTools.cursor) ;
    	optionComboBox.setBorder(BorderFactory.createTitledBorder("��ѯѡ��")) ;
    	optionComboBox.addActionListener(this) ;
    	optionComboBox.addItemListener(this) ;
    	String[] condition01 = {"������","����","�ǳ���","��","�е���","��΢�е���","����","��΢�е���","�е���","��","�ǳ���","����","������","����","����","��Լ","�ӽ�","�ǳ��ӽ�","����ӽ�"} ;
    	this.conditionComboBox01 = new JComboBox(condition01) ;
    	conditionComboBox01.setCursor(MyTools.cursor) ;
    	conditionComboBox01.setBorder(BorderFactory.createTitledBorder("��ѯ����")) ;
    	conditionComboBox01.addActionListener(this) ;
    	conditionComboBox01.addItemListener(this) ;
    	Object[] condition02 ={"ƽ��ֵ","ƽ��ֵ��һ��"} ;
    	conditionComboBox02 = new JComboBox(condition02) ;
    	conditionComboBox02.setCursor(MyTools.cursor) ;
    	conditionComboBox02.setEditable(true) ;
    	conditionComboBox02.setVisible(false) ;//���ò��ɼ�
    	conditionComboBox02.setBorder(BorderFactory.createTitledBorder("����")) ;
    	conditionComboBox02.addActionListener(this) ;
    	this.highQueryButton = new JButton("��ѯ") ;
    	highQueryButton.setCursor(MyTools.cursor) ;
    	highQueryButton.addActionListener(this) ;
    	topHighPanel.add(optionComboBox) ;
    	topHighPanel.add(conditionComboBox01) ;
    	topHighPanel.add(conditionComboBox02) ;
    	topHighPanel.add(highQueryButton) ;
    	cardLayoutPanel.add(topHighPanel,"topHighPanel") ;
    	topPanel.add(cardLayoutPanel,BorderLayout.CENTER) ;
    	panel.add(topPanel,BorderLayout.NORTH) ;
    	//����
    	this.table = new JTable(){
			private static final long serialVersionUID = 8129104276997951782L;
			@Override
			public boolean isCellEditable(int row, int column) {
				return false ;
			}
    	} ;
    	table.addMouseListener(this) ;
		JScrollPane jsp = new JScrollPane(this.table,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED) ;
		panel.add(jsp,BorderLayout.CENTER) ;
		//���
		this.bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER,10,10)) ;
		label = new JLabel() ;
		this.setLable(label) ;
		bottomPanel.add(label) ;
		panel.add(bottomPanel,BorderLayout.SOUTH) ; 
    	return panel ;
    }
	@Override
	public void actionPerformed(ActionEvent e) {
		this.tableModel= new DefaultTableModel(null,this.titles) ;
		if(e.getSource() == this.commonQueryButton){
			int currentPage = 1 ;//��ǰҳ
			int lineSize = 10 ;//ÿҳ��ʾ����
			int allRecorders = 0 ;
			if(this.text.getText()==null||"".equals(this.text.getText())){
				JOptionPane.showMessageDialog(frame,"����Ϊ�գ�") ;
				return ;
			}
			this.runTime = System.currentTimeMillis() ;
			this.option = this.text.getText().trim() ;
			try {
				all = DaoFactory.getFacultyDaoInstance().getByKeyword(option, currentPage, lineSize) ;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			Iterator<Faculty> iter = all.iterator() ;
			while(iter.hasNext()){
				Faculty faculty = iter.next() ;
				userInfo = new Object[13] ;
				userInfo[0] = faculty.getName() ;
				userInfo[1] = faculty.getSex() ;
				userInfo[2] = MyTools.sdf.format(faculty.getBirthday()) ;
				userInfo[3] = faculty.getNation() ;
				userInfo[4] = faculty.getTelephone() ;
				userInfo[5] = faculty.getEmail() ;
				userInfo[6] = faculty.getWorkload() ;
				userInfo[7] = faculty.getWages() ;
				userInfo[8] = faculty.getWorkplace() ;
				userInfo[9] = faculty.getSpecialty() ;
				userInfo[10] = faculty.getTechnicalTitles() ;
				userInfo[11] = faculty.getRemarks() ;
				tableModel.addRow(userInfo) ;
			}	
			this.table.setModel(tableModel) ;
			this.size = tableModel.getRowCount() ;
			this.setLable(label) ;
			this.runTime = System.currentTimeMillis()-this.runTime;
			System.out.println("��ѯʱ�䣺"+this.runTime+"����") ;
		}else if(e.getSource() == this.highQueryButton){
			int currentPage = 1 ;//��ǰҳ
			int lineSize = 10 ;//ÿҳ��ʾ����
			this.runTime = System.currentTimeMillis() ;
			this.option = (String)optionComboBox.getSelectedItem() ;
			int n = conditionComboBox01.getSelectedIndex() ;
			String condition01 = conditionComboBox01.getSelectedItem().toString() ;
			String condition02 = conditionComboBox02.getSelectedItem().toString() ;
			if(n<13){    //��Ȩ��
				String pow = null ;
				switch (n){
				case 0:pow="absolutely high";break;
				case 1:pow="extremely high";break;
				case 2:pow="very high";break;
				case 3:pow="high";break;
				case 4:pow="fairly high";break;
				case 5:pow="somewhat high";break;
				case 6:pow="medium";break;
				case 7:pow="somewhat low";break;
				case 8:pow="fairly low";break;
				case 9:pow="low";break;
				case 10:pow="very low";break;
				case 11:pow="extremely low";break;
				case 12:pow="absolutely low";break;
				}
				if("������".equals(option)){
					option = "workload" ;
					this.setRangeByPowerValue(pow,2,30) ;
				}else if("����".equals(option)){
					option = "wages" ;
					this.setRangeByPowerValue(pow,800,6000) ;
				}
				try {
					this.all= DaoFactory.getFacultyDaoInstance().getByConditionRange(option, this.minValue, this.maxValue, 3,currentPage,lineSize) ;
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}else{    //����Χ
				this.runTime = System.currentTimeMillis() ;
				if("������".equals(option)){
					option = "workload" ;
					this.minValue = 2f ;
					this.maxValue = 30f;
				}else if("����".equals(option)){
					option = "wages" ;
					this.minValue = 800f ;
					this.maxValue = 6000f ;
				}
				if("����".equals(condition01)){
					if(condition02.matches("^\\d+(\\.\\d+)?$")){
					    this.maxValue = Float.parseFloat(condition02) ;
					}else {
						if("��ƽ��ֵ".equals(condition02)||"ƽ��ֵ".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option);
							} catch (Exception e1) {
								e1.printStackTrace();
							} 
							this.maxValue = avg ;
						}else if("��ƽ��ֵ��һ��".equals(condition02)||"ƽ��ֵ��һ��".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option)/2;
							} catch (Exception e1) {
								e1.printStackTrace();
							} 
							this.maxValue = avg ;
						}else{
							this.setErrorLable(label) ;
							return ;
						}
					}
					try {
						this.all = DaoFactory.getFacultyDaoInstance().getByConditionRange(option,this.minValue,this.maxValue,2,currentPage,lineSize) ;
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}else if("����".equals(condition01)){
					if(condition02.matches("^\\d+(\\.\\d+)?$")){
					    this.minValue = Float.parseFloat(condition02) ;
					}else {
						if("��ƽ��ֵ".equals(condition02)||"ƽ��ֵ".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option);
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.minValue = avg ;
						}else if("��ƽ��ֵ��һ��".equals(condition02)||"ƽ��ֵ��һ��".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option)/2;
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.minValue = avg ;
						}else{
							this.setErrorLable(label) ;
							return ;
						}	
					}
					try {
						this.all = DaoFactory.getFacultyDaoInstance().getByConditionRange(option,this.minValue,this.maxValue,1,currentPage,lineSize) ;
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}else if("��Լ".equals(condition01)){
					if(condition02.matches("^\\d+(\\.\\d+)?$")){
						this.setRangeByCounterworld(option, "very high",Float.parseFloat(condition02)) ;
					}else {
						if("��ƽ��ֵ".equals(condition02)||"ƽ��ֵ".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option);
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.setRangeByCounterworld(option,"very high", avg) ;
						}else if("��ƽ��ֵ��һ��".equals(condition02)||"ƽ��ֵ��һ��".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option)/2;
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.setRangeByCounterworld(option,"very high", avg) ;
						}else{
							this.setErrorLable(label) ;
							return ;
						}
					}
					try {
						this.all = DaoFactory.getFacultyDaoInstance().getByConditionRange(option,this.minValue,this.maxValue,3,currentPage,lineSize) ;
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}else if("�ӽ�".equals(condition01)){
					if(condition02.matches("^\\d+(\\.\\d+)?$")){
						this.setRangeByCounterworld(option, "medium",Float.parseFloat(condition02)) ;
					}else {
						if("ƽ��ֵ".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option);
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.setRangeByCounterworld(option,"medium", avg) ;
						}else if("ƽ��ֵ��һ��".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option)/2;
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.setRangeByCounterworld(option,"medium", avg) ;
						}else{
							this.setErrorLable(label) ;
							return ;
						}
					}
					try {
						this.all = DaoFactory.getFacultyDaoInstance().getByConditionRange(option,this.minValue,this.maxValue,3,currentPage,lineSize) ;
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}else if("�ǳ��ӽ�".equals(condition01)){
					if(condition02.matches("^\\d+(\\.\\d+)?$")){
						this.setRangeByCounterworld(option, "very high",Float.parseFloat(condition02)) ;
					}else {
						if("ƽ��ֵ".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option);
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.setRangeByCounterworld(option,"very high", avg) ;
						}else if("ƽ��ֵ��һ��".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option)/2;
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.setRangeByCounterworld(option,"very high", avg) ;
						}else{
							this.setErrorLable(label) ;
							return ;
						}
					}
					try {
						this.all = DaoFactory.getFacultyDaoInstance().getByConditionRange(option,this.minValue,this.maxValue,3,currentPage,lineSize) ;
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}else if("����ӽ�".equals(condition01)){
					if(condition02.matches("^\\d+(\\.\\d+)?$")){
						this.setRangeByCounterworld(option, "extremely high",Float.parseFloat(condition02)) ;
					}else {
						if("ƽ��ֵ".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option);
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.setRangeByCounterworld(option,"extremely high", avg) ;
						}else if("ƽ��ֵ��һ��".equals(condition02)){
							float avg = 0f ;
							try {
								avg = DaoFactory.getPersonDaoInstance().getAvgByCondition(option)/2;
							} catch (Exception e1) {
								e1.printStackTrace();
							}
							this.setRangeByCounterworld(option,"extremely high", avg) ;
						}else{
							this.setErrorLable(label) ;
							return ;
						}
					}
					try {
						this.all = DaoFactory.getFacultyDaoInstance().getByConditionRange(option,this.minValue,this.maxValue,3,currentPage,lineSize) ;
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
			Iterator<Faculty> iter = all.iterator() ;
			while(iter.hasNext()){
				Faculty faculty = iter.next() ;
				userInfo = new Object[13] ;
				userInfo[0] = faculty.getName() ;
				userInfo[1] = faculty.getSex() ;
				userInfo[2] = MyTools.sdf.format(faculty.getBirthday()) ;
				userInfo[3] = faculty.getNation() ;
				userInfo[4] = faculty.getTelephone() ;
				userInfo[5] = faculty.getEmail() ;
				userInfo[6] = faculty.getWorkload() ;
				userInfo[7] = faculty.getWages() ;
				userInfo[8] = faculty.getWorkplace() ;
				userInfo[9] = faculty.getSpecialty() ;
				userInfo[10] = faculty.getTechnicalTitles() ;
				userInfo[11] = faculty.getRemarks() ;
				tableModel.addRow(userInfo) ;
			}
			this.table.setModel(tableModel) ;
			this.size = this.all.size() ;
			this.setLable(label) ;
			this.runTime = System.currentTimeMillis()-this.runTime;
			System.out.println("��ѯʱ�䣺"+this.runTime+"����") ;
		}
	}
    
	@Override
	public void itemStateChanged(ItemEvent e) {
		if(e.getSource()==this.optionComboBox){
			if(e.getStateChange()==ItemEvent.SELECTED){
				this.conditionComboBox02.setVisible(false) ;
				String option = e.getItem().toString() ;
				if("������".equals(option)){
					Object[] condition = {"������","����","�ǳ���","��","�е���","��΢�е���","����","��΢�е���","�е���","��","�ǳ���","����","������","����","����","��Լ","�ӽ�","�ǳ��ӽ�","����ӽ�"} ;
					this.conditionComboBox01.setModel(new DefaultComboBoxModel(condition)) ;
				}else if("����".equals(option)){
					Object[] condition = {"���Ը�","����","�ǳ���","��","�е��","��΢�е��","����","��΢�е��","�е��","��","�ǳ���","����","���Ե�","����","����","��Լ","�ӽ�","�ǳ��ӽ�","����ӽ�"} ;
					this.conditionComboBox01.setModel(new DefaultComboBoxModel(condition)) ;
				}
			}
		}else if(e.getSource()==this.conditionComboBox01){
			if(e.getStateChange()==ItemEvent.SELECTED){
				String condition = e.getItem().toString() ;
				if("����".equals(condition)||"����".equals(condition)||"��Լ".equals(condition)||"�ӽ�".equals(condition)||"�ǳ��ӽ�".equals(condition)||"����ӽ�".equals(condition)){
					this.conditionComboBox02.setVisible(true) ;
				}else{
					this.conditionComboBox02.setVisible(false) ;
				}
			}
		}else if(e.getSource()==this.chooseComboBox){
			if(e.getStateChange()==ItemEvent.SELECTED){
				String condition = e.getItem().toString() ;
				if("�߼���ѯ".equals(condition)){
					this.cardLayout.show(this.cardLayoutPanel,"topHighPanel") ;
				}else if("��ͨ��ѯ".equals(condition)){
					this.cardLayout.show(this.cardLayoutPanel,"topCommonPanel") ;
				}
			}
		}
	}
	//����Ȩֵӳ�������ȡֵ��Χ
	public void setRangeByPowerValue(String pow,float min,float max){
		Map<String,PowerValue> map = PowerTable.getPowerTable() ;
		this.minValue=map.get(pow).getLeftLimit()*(max-min)+min ;
		this.maxValue= map.get(pow).getRightLimit()*(max-min)+min ;
	}
	public void setErrorLable(JLabel label){
		label.setFont(new Font("����",Font.BOLD,15)) ;
		label.setForeground(Color.RED) ;
		label.setText("���������֧�ֵĲ�ѯ��");
	}
	public void setLable(JLabel label){
		label.setFont(new Font("����",Font.BOLD,15)) ;
		label.setForeground(Color.BLACK) ;
		if(this.size>=0&&this.maxValue!=0&&this.minValue!=0){
			label.setText("��ѯ��Χ:     "+this.minValue+"��"+this.maxValue+"            "+"        ����    "+this.size+"   ����¼��������") ;
			this.maxValue = 0 ;
			this.minValue = 0 ;
		}else if(this.size>=0&&this.maxValue==0&&this.minValue==0){
			label.setText("����    "+this.size+"   ����¼��������") ;
		}else{
			label.setText("��ѯ��Χ:                               ����        ����¼��������") ;
		}
	}
	//����ģ��������ȡֵ��Χ
	public void setRangeByCounterworld(String option,String minStr,float y){
		Map<String,PowerValue> map = PowerTable.getPowerTable() ;
		float min = map.get(minStr).getLeftLimit();
		float b = (y/10)*3 ;
		this.maxValue = (float) (y+b*Math.sqrt(1.0/min-1)) ;
		this.minValue = 2*y-this.maxValue ;
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getClickCount()==2){
			//System.out.println(table.getValueAt(table.getSelectedRow(),0));
		}
	}
}