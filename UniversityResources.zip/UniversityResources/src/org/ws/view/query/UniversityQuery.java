package org.ws.view.query;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.ws.factory.DaoFactory;
import org.ws.tools.MyTools;
import org.ws.util.WordSimilarity;
import org.ws.view.query.show.ShowQuery;
import org.ws.vo.major.Major;
import org.ws.vo.organization.University;

public class UniversityQuery extends MouseAdapter implements ActionListener {

	private JPanel panel;// �����
	private JPanel toppanel,searchwaypanel,inputpanel;
	private JLabel label_searchway,label_input;// ��У��ѯ��
	private JRadioButton nameradio,majorradio,arearadio;
	private ButtonGroup buttongroup ;//��ť��
	private JTextField textField;
	private JButton button;
	private Box box;// �����ʾ
	private JScrollPane jsp;// �����������
	private JFrame frame;
	private JTable table;
	private String[] titles = { "���", "����","����ʡ��","����רҵ" };
	private DefaultTableModel tableModel;
	private ShowQuery show;// ��������ϸ��Ϣ����

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UniversityQuery window = new UniversityQuery();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public UniversityQuery() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame("��У��ѯ");
		frame.add(this.getJPanel());
		frame.setBounds(MyTools.width / 2 - 512, MyTools.height / 2 - 384,
				1024, 738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		show = new ShowQuery();
	}

	public JPanel getJPanel() {
		panel = new JPanel(new BorderLayout());
		toppanel = new JPanel(new GridLayout(2,1));//����
		searchwaypanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		label_searchway = new JLabel("��ѯ��ʽ��");
		label_searchway.setFont(MyTools.font2);
		searchwaypanel.add(label_searchway);
		nameradio = new JRadioButton("�����Ʋ�ѯ",true) ;
		majorradio = new JRadioButton("��רҵ��ѯ") ;
		arearadio = new JRadioButton("��������ѯ") ;
		buttongroup = new ButtonGroup() ;
		buttongroup.add(nameradio) ;//����ѡ��ť������
		buttongroup.add(majorradio) ;//����ѡ��ť������
		buttongroup.add(arearadio) ;//����ѡ��ť������
		searchwaypanel.add(nameradio) ; 
		searchwaypanel.add(majorradio) ; 
		searchwaypanel.add(arearadio) ; 
		toppanel.add(searchwaypanel) ;
		//�������
		inputpanel = new JPanel(new FlowLayout(FlowLayout.CENTER)) ;
		label_input = new JLabel("�������ơ�רҵ�����:") ;
		label_input.setFont(MyTools.font2);
		inputpanel.add(label_input) ;
		textField = new JTextField(20);
		inputpanel.add(textField);
		button = new JButton("��ѯ");
		button.addActionListener(this);
		button.setCursor(MyTools.cursor);
		inputpanel.add(button);
		toppanel.add(inputpanel) ;
		
		panel.add(toppanel, BorderLayout.NORTH);

		box = Box.createVerticalBox();
		panel.add(box, BorderLayout.CENTER);
		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		tableModel = new DefaultTableModel(null, this.titles);
		if (e.getSource() == button) {
			int currentPage = 1;
			int lineSize = 10;
			if (this.textField.getText() == null
					|| "".equals(this.textField.getText())) {
				JOptionPane.showMessageDialog(frame, "����Ϊ�գ�");
				return;
			}
			String keyword = this.textField.getText();
			List<University> all = null;
			box.removeAll();// �Ƴ�ȫ��
			/*�����Ʋ�ѯ*/
			if(nameradio.isSelected()){
				Map<String, Double> map = WordSimilarity.getWordsBySimilarity(
						keyword, MyTools.SIMILARITY);
				try {
					all = DaoFactory.getUniversityDaoInstance().getByKeywordMap(
							map, currentPage, lineSize);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				box.add(new JLabel("�ؼ��֣�" + keyword));
				StringBuffer relatedkey = new StringBuffer();
				for (String key : map.keySet()) {
					relatedkey.append(key + "  ");
				}
				String[] str = relatedkey.toString().split("  ");
				if (str.length > 10) {
					// ��ش�̫��
					relatedkey = new StringBuffer();
					for (int i = 0; i < 10; i++) {
						relatedkey.append(str[i] + "  ");
					}
				}
				this.box.add(new JLabel("��شʣ�" + relatedkey.toString()));
				box.add(Box.createVerticalStrut(10));// ���Ӵ�ֱ֧��
			}
			/*��רҵ��ѯ*/
			if(majorradio.isSelected()){
				try {
					all = DaoFactory.getUniversityDaoInstance().getByMajor(keyword, currentPage, lineSize) ;
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			/*��������ѯ*/
			if(arearadio.isSelected()){
				if("��������".equals(keyword)||"����".equals(keyword)){
					keyword = "Northwest" ;
				}else if("��������".equals(keyword)||"����".equals(keyword)){
					keyword = "Northeast" ;
				}else if("���ϵ���".equals(keyword)||"����".equals(keyword)){
					keyword = "Southwest" ;
				}else if("���ϵ���".equals(keyword)||"����".equals(keyword)){
					keyword = "Southeast" ;
				}else if("��������".equals(keyword)||"����".equals(keyword)){
					keyword = "EastChina" ;
				}else if("��������".equals(keyword)||"����".equals(keyword)){
					keyword = "WestChina" ;
				}else if("��������".equals(keyword)||"����".equals(keyword)){
					keyword = "NorthChina" ;
				}else if("���ϵ���".equals(keyword)||"����".equals(keyword)){
					keyword = "SouthChina" ;
				}else if("���е���".equals(keyword)||"����".equals(keyword)){
					keyword = "CenterChina" ;
				}else{
					JOptionPane.showMessageDialog(frame, "����Ĺؼ�������");
					return ;
				}
				try {
					all = DaoFactory.getUniversityDaoInstance().getByArea(keyword, currentPage, lineSize) ;
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
			if (all==null || all.size()<=0) {
				JOptionPane.showMessageDialog(frame, "����ؼ�¼��");
				return;
			}
			
			
			// ����
			table = new JTable() {
				private static final long serialVersionUID = 1L;
				public boolean isCellEditable(int row, int column) {
					return false;
				}
			};
			table.addMouseListener(this);
			jsp = new JScrollPane(table,
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			box.add(jsp);
			Iterator<University> iter = all.iterator();
			while (iter.hasNext()) {
				University uni = iter.next();
				Object[] obj = new Object[4];
				obj[0] = uni.getId();
				obj[1] = uni.getName();
				obj[2] = uni.getArea().getName() ;
				StringBuffer buf = new StringBuffer() ;
				List<Major> list = uni.getMarjors() ;
				Iterator<Major> it = list.iterator() ;
				while(it.hasNext()){
					Major major = it.next() ;
					buf.append(major.getName()+"\t ") ;
				}
				obj[3] = buf.toString() ;
				tableModel.addRow(obj);
			}
			table.setModel(tableModel);
			box.validate();// ��Ч
			box.repaint() ;//�ػ�
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			String id = (String) table.getValueAt(table.getSelectedRow(), 0);
			University uni = null;
			try {
				uni = DaoFactory.getUniversityDaoInstance().getById(id);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			show.getTopicLabel().setText(uni.getName());
			show.getContentTextArea().setText(uni.getIntroduction());
			show.getFrame().setVisible(true);
		}
	}

}
