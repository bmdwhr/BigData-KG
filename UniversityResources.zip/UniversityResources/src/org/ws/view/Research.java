package org.ws.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

import org.ws.tools.MyTools;
import org.ws.view.research.OrganizationResearch;
import org.ws.view.research.PersonResearch;
import org.ws.view.research.ThemeResearch;

public class Research {
	public JTabbedPane tabbedPane ;
	private JFrame frame  ;
	public Research(){
		initialize() ;
	}
	private void initialize(){
		frame = new JFrame("���и���") ;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		frame.add(this.getTabbedPane()) ;
		frame.setSize(1024,738) ;
		frame.setLocation(MyTools.width/2-512,MyTools.height/2-384) ;
	}
	public JTabbedPane getTabbedPane(){
		tabbedPane = new JTabbedPane() ;
		tabbedPane.addTab("�������",new ThemeResearch().getJScrollPane()) ;
		tabbedPane.addTab("�������",new PersonResearch().getJScrollPane()) ;
		tabbedPane.addTab("��������",new OrganizationResearch().getJScrollPane()) ;
		//tabbedPane.addTab("�����ѯ",new ThemeQuery().getJScrollPane()) ;
		//tabbedPane.addTab("�����ѯ",new PersonQuery().getJScrollPane()) ;
		//tabbedPane.addTab("������ѯ",new OrganizationQuery().getJScrollPane()) ;
		return tabbedPane ;
	}
	public static void main(String args[]){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Research window = new Research();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
