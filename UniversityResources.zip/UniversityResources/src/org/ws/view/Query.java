package org.ws.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

import org.ws.tools.MyTools;
import org.ws.view.query.DepartmentQuery;
import org.ws.view.query.FacultyQueryHasBSD;
import org.ws.view.query.UniversityQuery;

public class Query {
	public JTabbedPane tabbedPane ;
	private JFrame frame;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Query window = new Query();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Query() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame("��ʦ����");
		frame.add(this.getTabbedPane()) ;
		frame.setBounds(MyTools.width/2-512,MyTools.height/2-384,1024,738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public JTabbedPane getTabbedPane(){
		tabbedPane = new JTabbedPane() ;
		tabbedPane.add("��ʦ��ѯ",new FacultyQueryHasBSD().getPanel()) ;
		tabbedPane.add("���Ų�ѯ",new DepartmentQuery().getJPanel()) ;
		tabbedPane.add("��У��ѯ",new UniversityQuery().getJPanel()) ;
		return tabbedPane ;
	}

}
