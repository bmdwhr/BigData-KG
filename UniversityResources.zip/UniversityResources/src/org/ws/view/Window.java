package org.ws.view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import org.ws.tools.ImagePanel;
import org.ws.tools.MyTools;
import org.ws.view.query.DepartmentQuery;
import org.ws.view.query.FacultyQueryHasBSD;
import org.ws.view.query.UniversityQuery;
import org.ws.view.research.OrganizationResearch;
import org.ws.view.research.PersonResearch;
import org.ws.view.research.ThemeResearch;

public class Window extends MouseAdapter implements ActionListener,TreeSelectionListener {

	private JFrame frame;
	private JMenuBar menuBar ;
	private JMenu menu_file,menu_help ;
	private JMenuItem menuItem_cancel,menuItem_exit,menuItem_about,menuItem_bench;
	private JToolBar toolBar ; 
	private JButton button_cancel ;
	private JSplitPane jsp ;
	private JPanel centerPanel_left,centerPanel_right;
	private CardLayout cardLayout ;
	private JTree tree;
	private DefaultMutableTreeNode root,peopleNode,facultyNode,departmentNode,universityNode,researchNode,themeNode,personNode,organizationNode ;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new Window();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Window() {
		initialize();
	}
	/**
	 * ��ʼ���˵���
	 */
	private void initMenuBar(){
		menuBar = new JMenuBar() ;
		menu_file = new JMenu("�ļ�") ;
		menu_file.setFont(MyTools.font2) ;
		menuItem_cancel = new JMenuItem("�л��û�") ;
		menuItem_cancel.setFont(MyTools.font1) ;
		menuItem_cancel.addActionListener(this) ;
		menu_file.add(menuItem_cancel) ;
		menuItem_exit = new JMenuItem("�˳�") ;
		menuItem_exit.setFont(MyTools.font1) ;
		menuItem_exit.addActionListener(this) ;
		menu_file.add(menuItem_exit) ;
		menu_help = new JMenu("����") ;
		menu_help.setFont(MyTools.font2) ;
		menuItem_bench = new JMenuItem("�鿴����") ;
		menuItem_bench.addActionListener(this) ;
		menuItem_bench.setFont(MyTools.font1) ;
		menu_help.add(menuItem_bench) ;
		menuItem_about = new JMenuItem("��������") ;
		menuItem_about.addActionListener(this) ;
		menuItem_about.setFont(MyTools.font1) ;
		menu_help.add(menuItem_about) ;
		menuBar.add(menu_file) ;
		menuBar.add(menu_help) ;
		frame.setJMenuBar(menuBar) ;
	}
	/**
	 * ��ʼ��������
	 */
	private void initToolBar(){
		toolBar = new JToolBar() ;
		toolBar.setEnabled(false) ;
		button_cancel = new JButton(new ImageIcon("image"+File.separator+"cancel_20.png")) ;
		button_cancel.addActionListener(this) ;
		button_cancel.setCursor(MyTools.cursor) ;//���ù��
		button_cancel.setToolTipText("�л��û�") ;//���ͣ��ʱ��ʾ
		toolBar.add(button_cancel) ;
		frame.getContentPane().add(toolBar,BorderLayout.NORTH) ;
	}
	/**
	 * ��ʼ���м����
	 */
	private void initCenterPanel(){
		jsp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT) ;
		jsp.setDividerLocation(200) ;//���÷ָ���λ��
		jsp.setDividerSize(7) ;//���÷ָ��ߴ�С
		jsp.setOneTouchExpandable(true) ;//���۵�
		centerPanel_left = new JPanel(new GridLayout(2,1)) ;
		centerPanel_left.setBackground(Color.WHITE);
		tree = new JTree();
		tree.addTreeSelectionListener(this) ;
		tree.setFont(new Font("����", Font.PLAIN, 25));
		root = new DefaultMutableTreeNode("����") ;
		peopleNode = new DefaultMutableTreeNode("��Ա����") ;
		facultyNode = new DefaultMutableTreeNode("��ʦ����") ;
		departmentNode = new DefaultMutableTreeNode("���Ź���") ;
		universityNode = new DefaultMutableTreeNode("��У����") ;
		peopleNode.add(facultyNode) ;
		peopleNode.add(departmentNode) ;
		peopleNode.add(universityNode) ;
		root.add(peopleNode) ;
		researchNode = new DefaultMutableTreeNode("���и���") ;
		themeNode = new DefaultMutableTreeNode("�о�����") ;
		personNode = new DefaultMutableTreeNode("�о���Ա") ;
		organizationNode = new DefaultMutableTreeNode("�о�����") ;
		researchNode.add(themeNode) ;
		researchNode.add(personNode) ;
		researchNode.add(organizationNode) ;
		root.add(researchNode) ;
		tree.setModel(new DefaultTreeModel(root));
		centerPanel_left.add(tree);
		jsp.add(centerPanel_left) ;
		//�ұ�
		cardLayout = new CardLayout() ;
		centerPanel_right = new JPanel(cardLayout) ;
		Image image = null ;
		try {
			image = ImageIO.read(new File("image"+File.separator+"bench.png")) ;
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		ImagePanel imagePanel = new ImagePanel(image,MyTools.width,MyTools.height) ;
		centerPanel_right.add(imagePanel,"bench") ;
		Image image_about = null ;
		try {
			image_about = ImageIO.read(new File("image"+File.separator+"about.png")) ;
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		ImagePanel imagePanel_about = new ImagePanel(image_about,MyTools.width,MyTools.height) ;
		centerPanel_right.add(imagePanel_about,"about") ;//��������
		centerPanel_right.add(new FacultyQueryHasBSD().getPanel(),"facultyquery") ;
		centerPanel_right.add(new DepartmentQuery().getJPanel(),"departmentquery") ;
		centerPanel_right.add(new UniversityQuery().getJPanel(),"universityquery") ;
		centerPanel_right.add(new ThemeResearch().getJScrollPane(),"themeresearch") ;
		centerPanel_right.add(new PersonResearch().getJScrollPane(),"personresearch") ;
		centerPanel_right.add(new OrganizationResearch().getJScrollPane(),"organizationresearch") ;
		jsp.add(centerPanel_right) ;
		frame.getContentPane().add(jsp,BorderLayout.CENTER) ;
	}
	//��ʼ��
	private void initialize() {
		frame = new JFrame("��У��Դ���ܹ���ϵͳ");
		this.initMenuBar() ;
		this.initToolBar() ;
		this.initCenterPanel() ;
		frame.setVisible(true) ;
		frame.setSize(1024,738) ;
		frame.setLocation(MyTools.width/2-512,MyTools.height/2-384) ;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		/*if(e.getSource()==this.label_research){
			this.cardLayout.show(this.centerPanel_right,"research") ;
		}else if(e.getSource()==this.label_query){
			this.cardLayout.show(this.centerPanel_right,"query") ;
		}*/
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		/*if(e.getSource()==this.label_research){
			label_research.setEnabled(true) ;	
		}else if(e.getSource()==this.label_query){
			label_query.setEnabled(true) ;	
		}*/
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		/*if(e.getSource()==this.label_research){
			label_research.setEnabled(false) ;	
		}else if(e.getSource()==this.label_query){
			label_query.setEnabled(false) ;	
		}*/
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.menuItem_cancel||e.getSource()==this.button_cancel){
			int option = JOptionPane.showConfirmDialog(this.frame,"ȷ��Ҫ���µ�¼��","��ʾ",0) ;
			if(option==JOptionPane.YES_OPTION){
				this.frame.dispose() ;
				new Login() ;
			}	
		}else if(e.getSource()==this.menuItem_about){
			this.cardLayout.show(this.centerPanel_right,"about") ;
		}else if(e.getSource()==this.menuItem_bench){
			this.cardLayout.show(this.centerPanel_right,"bench") ;
		}else if(e.getSource()==this.menuItem_exit){
			this.frame.dispose() ;
		}
		
	}
	@Override
	public void valueChanged(TreeSelectionEvent e) {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent() ;
		if(node==facultyNode){
			cardLayout.show(this.centerPanel_right,"facultyquery") ;
		}else if(node==departmentNode){
			cardLayout.show(this.centerPanel_right,"departmentquery") ;
		}else if(node==universityNode){
			cardLayout.show(this.centerPanel_right,"universityquery") ;
		}else if(node==themeNode){
			cardLayout.show(this.centerPanel_right,"themeresearch") ;
		}else if(node==personNode){
			cardLayout.show(this.centerPanel_right,"personresearch") ;
		}else if(node==organizationNode){
			cardLayout.show(this.centerPanel_right,"organizationresearch") ;
		}
	}

}
