package org.ws.vo.person;

/**
 * 
 * @author ��˳
 *  ���
 */
public class ClericalStaff extends AdministrativeStaff {

}
