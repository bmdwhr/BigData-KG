package org.ws.vo.person;

/**
 * 
 * @author ��˳
 *  ϵͳ����Ա
 */
public class SystemsStaff extends AdministrativeStaff {
	private String adminid ;//����Ա�ʺ�
	private String adminpwd ;//����Ա����
	public String getAdminid() {
		return adminid;
	}
	public void setAdminid(String adminid) {
		this.adminid = adminid;
	}
	public String getAdminpwd() {
		return adminpwd;
	}
	public void setAdminpwd(String adminpwd) {
		this.adminpwd = adminpwd;
	}
}
