package org.ws.vo.person;

/**
 * 
 * @author ��˳
 *  ����ְԱ
 */
public class AdministrativeStaff extends Employee {
	
}
