package org.ws.vo.person;

import org.ws.vo.organization.Organization;

/**
 * 
 * @author ��˳
 *  ��Ӷ��Ա
 */
public class Employee extends Person {
	private int workload ;//������
	private float wages ;//����
	private Organization organization ;//�����ĸ���֯
	
	//�����
	private float uC ;
	private float uP ;
	private float rCP ;
	
	public Organization getOrganization() {
		return organization;
	}
	public void setOrganization(Organization organization) {
		this.organization = organization;
	}
	public int getWorkload() {
		return workload;
	}
	public void setWorkload(int workload) {
		this.workload = workload;
	}
	public float getWages() {
		return wages;
	}
	public void setWages(float wages) {
		this.wages = wages;
	}
	public float getuC() {
		return uC;
	}
	public void setuC(float uC) {
		this.uC = uC;
	}
	public float getuP() {
		return uP;
	}
	public void setuP(float uP) {
		this.uP = uP;
	}
	public float getrCP() {
		return rCP;
	}
	public void setrCP(float rCP) {
		this.rCP = rCP;
	}
	
}
