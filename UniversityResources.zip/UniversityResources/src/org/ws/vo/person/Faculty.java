package org.ws.vo.person;

/**
 * 
 * @author ��˳
 *  ȫ���Ա
 */
public class Faculty extends Employee {
	private String workplace ;//������λ
	private String specialty ;//רҵ�����ογ�
	private String technicalTitles ;//רҵ����ְ��
	public String getWorkplace() {
		return workplace;
	}
	public void setWorkplace(String workplace) {
		this.workplace = workplace;
	}
	public String getSpecialty() {
		return specialty;
	}
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}
	public String getTechnicalTitles() {
		return technicalTitles;
	}
	public void setTechnicalTitles(String technicalTitles) {
		this.technicalTitles = technicalTitles;
	}
	
}
