package org.ws.vo.person;

/**
 * 
 * @author ��˳
 *  ȫְ����
 */
public class FullProfessor extends Professor {

}
