package org.ws.vo.person;

/**
 * 
 * @author ��˳
 *  Ժ��
 */
public class Dean extends Person {

}
