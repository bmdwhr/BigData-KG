package org.ws.vo.person;

/**
 * 
 * @author ��˳
 *  ��ʦ
 */
public class Lecturer extends Faculty {

}
