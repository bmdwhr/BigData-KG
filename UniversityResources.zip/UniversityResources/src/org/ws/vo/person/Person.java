package org.ws.vo.person;

import java.util.Date;

/**
 * 
 * @author ��˳
 *	��
 */
public class Person {
	private String id ;//����֤����
	private String name ;//����
	private String sex ;
	private Date birthday ;
	private String nation ;//����
	private String telephone ;
	private String email ;
	private String remarks ;//��ע
	private String userid ;//�û���
	private String userpwd ;//����
	private String researchDirections ;//�о�����
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserpwd() {
		return userpwd;
	}
	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}
	public String getResearchDirections() {
		return researchDirections;
	}
	public void setResearchDirections(String researchDirections) {
		this.researchDirections = researchDirections;
	}
	
}
