package org.ws.vo.area;

/**
 * ����
 * @author ��˳
 *
 */
public class Area {
	private String name ;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
