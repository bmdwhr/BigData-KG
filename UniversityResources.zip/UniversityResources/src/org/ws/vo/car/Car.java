package org.ws.vo.car;

public class Car {
	private String id ;
	private String brand ;
	private float price ;
	private String version ;
	
	//������������
	private float uP ;
	private float uC ;
	private float rCP ;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public float getuP() {
		return uP;
	}
	public void setuP(float uP) {
		this.uP = uP;
	}
	public float getuC() {
		return uC;
	}
	public void setuC(float uC) {
		this.uC = uC;
	}
	public float getrCP() {
		return rCP;
	}
	public void setrCP(float rCP) {
		this.rCP = rCP;
	}
	
}
