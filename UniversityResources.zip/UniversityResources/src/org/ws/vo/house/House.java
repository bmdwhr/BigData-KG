package org.ws.vo.house;

public class House {
	
	private String id ;
	private float area ;
	private float price ;
	
	//������������
	private float uC;
	private float uP ;
	private float rCP ;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public float getArea() {
		return area;
	}
	public void setArea(float area) {
		this.area = area;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	public float getuC() {
		return uC;
	}
	public void setuC(float uC) {
		this.uC = uC;
	}
	public float getuP() {
		return uP;
	}
	public void setuP(float uP) {
		this.uP = uP;
	}
	public float getrCP() {
		return rCP;
	}
	public void setrCP(float rCP) {
		this.rCP = rCP;
	}
	
}
