package org.ws.vo.organization;

/**
 * 
 * @author ��˳
 *  ����
 */
public class Department extends Organization{

}
