package org.ws.vo.organization;

import org.ws.vo.area.Area;

/**
 * 
 * @author ��˳
 *	��֯
 */
public class Organization {
	private String id ;
	private String name ;
	private String introduction ; //���
	private Area area ;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public Area getArea() {
		return area;
	}
	public void setArea(Area area) {
		this.area = area;
	}
	
}
