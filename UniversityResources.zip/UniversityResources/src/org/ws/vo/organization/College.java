package org.ws.vo.organization;

/**
 * 
 * @author ��˳
 *  ��ѧ
 */
public class College extends Organization{

}
