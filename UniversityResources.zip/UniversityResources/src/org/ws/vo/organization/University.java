package org.ws.vo.organization;

import java.util.List;

import org.ws.vo.major.Major;

/**
 * 
 * @author ��˳
 *  �ۺ��Դ�ѧ
 */
public class University extends Organization{
	
	private List<Major> marjors ;//רҵ

	public List<Major> getMarjors() {
		return marjors;
	}

	public void setMarjors(List<Major> marjors) {
		this.marjors = marjors;
	}
	
}
