package org.ws.vo.organization;

/**
 * 
 * @author ��˳
 *  �о���
 */
public class ResearchGroup extends Organization{

}
