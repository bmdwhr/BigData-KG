package org.ws.vo.organization;

/**
 * 
 * @author ��˳
 *  ѧԺ
 */
public class Institute extends Organization{

}
