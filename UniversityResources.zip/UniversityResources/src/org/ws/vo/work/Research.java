package org.ws.vo.work;

/**
 * 
 * @author ��˳
 *	�о���Ʒ
 */
public class Research extends Work{
	private String content ;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
