package org.ws.vo.work;

/**
 * 
 * @author ��˳
 *	ר��
 */
public class Monograph extends Research{
	
}
