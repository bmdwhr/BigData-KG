package org.ws.vo.major;

/**
 * �Ŀ�
 * @author ��˳
 *
 */
public class Arts extends Major{

}
