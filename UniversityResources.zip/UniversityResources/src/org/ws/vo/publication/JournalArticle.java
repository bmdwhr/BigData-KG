package org.ws.vo.publication;

/**
 * 
 * @author ��˳
 *	��־
 */
public class JournalArticle extends Article {

}
