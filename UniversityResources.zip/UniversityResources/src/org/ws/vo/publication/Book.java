package org.ws.vo.publication;

/**
 * 
 * @author ��˳
 *	��
 */
public class Book extends Publication {

}
