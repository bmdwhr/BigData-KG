package org.ws.vo.publication;

/**
 * 
 * @author ��˳
 *	����
 */
public class Software extends Publication {

}
