package org.ws.vo.publication;

/**
 * 
 * @author ��˳
 *	�ֲ�
 */
public class Manual extends Publication {

}
