package org.ws.vo.publication;

/**
 * 
 * @author ��˳
 *	����
 */
public class Article extends Publication {
	private String content ;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
