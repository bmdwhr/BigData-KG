package org.ws.factory;

import org.ws.dao.ArticleDao;
import org.ws.dao.CarDao;
import org.ws.dao.DepartmentDao;
import org.ws.dao.FacultyDao;
import org.ws.dao.HouseDao;
import org.ws.dao.OrganizationDao;
import org.ws.dao.PersonDao;
import org.ws.dao.ProjectDao;
import org.ws.dao.ResearchDao;
import org.ws.dao.UniversityDao;
import org.ws.dao.proxy.ArticleDaoProxy;
import org.ws.dao.proxy.CarDaoProxy;
import org.ws.dao.proxy.DepartmentDaoProxy;
import org.ws.dao.proxy.FacultyDaoProxy;
import org.ws.dao.proxy.HouseDaoProxy;
import org.ws.dao.proxy.OrganizationDaoProxy;
import org.ws.dao.proxy.PersonDaoProxy;
import org.ws.dao.proxy.ProjectDaoProxy;
import org.ws.dao.proxy.ResearchDaoProxy;
import org.ws.dao.proxy.UniversityDaoProxy;

public class DaoFactory {
	public static PersonDao getPersonDaoInstance(){
		return new PersonDaoProxy() ;
	} 
	public static FacultyDao getFacultyDaoInstance(){
		return new FacultyDaoProxy() ;
	}
	public static ResearchDao getResearchDaoInstance(){
		return new ResearchDaoProxy() ;
	}
	public static ArticleDao getArticleDaoInstance(){
		return new ArticleDaoProxy() ;
	}
	public static UniversityDao getUniversityDaoInstance(){
		return new UniversityDaoProxy() ;
	}
	public static DepartmentDao getDepartmentDaoInstance(){
		return new DepartmentDaoProxy() ;
	}
	public static HouseDao getHouseDaoInstance(){
		return new HouseDaoProxy() ;
	}
	public static CarDao getCarDaoInstance(){
		return new CarDaoProxy() ;
	}
	public static OrganizationDao getOrganizationDaoInstance(){
		return new OrganizationDaoProxy() ;
	}
	public static ProjectDao getProjectDaoInstance(){
		return new ProjectDaoProxy() ;
	}
}
