package org.ws.tools;

import java.awt.Cursor;
import java.awt.Font;
import java.awt.Toolkit;
import java.text.SimpleDateFormat;

import org.jfree.chart.StandardChartTheme;

public class MyTools {
	public static int width = Toolkit.getDefaultToolkit().getScreenSize().width ;
	public static int height = Toolkit.getDefaultToolkit().getScreenSize().height ;
    public static Font font1 = new Font("����",Font.PLAIN,14) ;
    public static Font font2 = new Font("����",Font.PLAIN,16) ;
    public static Font font3 = new Font("����",Font.BOLD,20) ;
    public static double SIMILARITY = 0.9;//�������ƶ�
    public static Cursor cursor = new Cursor(Cursor.HAND_CURSOR) ;
    public static StandardChartTheme createStandardChartTheme(){
		StandardChartTheme chartTheme = new StandardChartTheme("cn") ;
		chartTheme.setExtraLargeFont(font3) ;
		chartTheme.setRegularFont(font2) ;
		chartTheme.setLargeFont(font2) ;
		return chartTheme ;
	}
    public static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
    public static String getQueryPrefix(){
    	return "PREFIX test: <http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#> "
		+"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
		+"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " ;
    }
    
    public static String getRules(){
    	return "[rule1:(?x http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#sameAs ?y) " +
		"(?x http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#topic ?z) " +
		"->(?y http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#topic ?z)]" 
		+"[rule2:(?x http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#sameAs ?y) " +
		"(?z http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#college_have ?x) " +
		"->(?z http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#college_have ?y)]";//������������
    }
    
    public static String getURI(){
    	return "http://www.lehigh.edu/~zhp2/2004/0401/univ-bench.owl#" ;
    }
}
