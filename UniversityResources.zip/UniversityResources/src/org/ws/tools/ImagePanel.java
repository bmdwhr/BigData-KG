package org.ws.tools;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JPanel;

public class ImagePanel extends JPanel{

	private static final long serialVersionUID = 1L;
	Image image ;
	public ImagePanel(Image image,int width,int height){
		this.image = image ;
		this.setSize(width,height) ;
	}
	public void paintComponent(Graphics g){
		super.printComponents(g) ;
		g.drawImage(this.image,0,0,this.getWidth(),this.getHeight(),this) ;
	}

}
