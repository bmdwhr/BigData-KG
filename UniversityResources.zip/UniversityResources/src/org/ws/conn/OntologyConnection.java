package org.ws.conn;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class OntologyConnection {
//	private static final String DRIVER = "org.gjt.mm.mysql.Driver" ;
//	private static final String URL = "jdbc:mysql://localhost/OntoDB" ;
//	private static final String USER = "root" ;
//	private static final String PASSWORD = "19900721" ;
//	private static final String DB = "MySQL" ;//���ݿ�����
	
	private OntModel model ;
	private InputStream input = null ;
	private Reader in = null ;
	public OntologyConnection(){
		File file = new File("bench"+File.separator+"univ-bench.owl") ;
		try {
			input = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		try {
			in= new InputStreamReader(input,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		model = ModelFactory.createOntologyModel();
		model.read(in,null);	
	}
	public OntModel getOntoModel(){
		return this.model ;
	}
	public void close(){
		if(in!=null){
			try {
				in.close() ;
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
		if(input!=null){
			try {
				input.close() ;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
}
