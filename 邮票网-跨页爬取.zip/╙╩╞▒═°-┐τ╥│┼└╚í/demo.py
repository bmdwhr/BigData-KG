import csv
import re
from sphinx.util import requests
from config import *



def get_shop_id():
    url = 'http://www.e1988.com/collectionproduct-215.html'
    response = requests.get(url =url, headers =HEADERS)
    response.encoding ='gbk'
    if response.status_code ==200:
        #print(response.text)
        re1 = re.compile('<li style="width:800px.*?#333;">(.*?)</li>',re.S)
        re2 = re.compile('商品ID：(\d+).*?<a href', re.S)
        re3 = re.compile('YaHei;">(.*?)</b>', re.S)
        re4 = re.compile('浏览量：(\d+)<br />', re.S)
        re5 = re.compile('【商品单位】：(.*?)</li>', re.S)
        re6 = re.compile('【全 套 数】：(.*?)</li>', re.S)
        re7 = re.compile('【整 张 数】：(.*?)</li>', re.S)
        re8 = re.compile('【发行日期】：(.*?)</li>', re.S)
        re9 = re.compile('【 规　格 】：(.*?)</li>', re.S)
        re10 = re.compile('【齿孔度数】：(.*?)</li>', re.S)
        re11 = re.compile('【设 计 者】：(.*?)</li>', re.S)
        re12 = re.compile('【 版　别 】：(.*?)</li>', re.S)
        re13 = re.compile('【印 刷 厂】：(.*?)</li>', re.S)
        re14 = re.compile('<p><STRONG>图案面值:(.*?)<span class=\'AddE1988String\'>', re.S)
        re15 = re.compile('标签：(.*?)</span><br />', re.S)
        re16 = re.compile('【藏品类别】 <A.*?">(.*?)</A>', re.S)
        shop_id = re.findall(re2, response.text)
        #print(response.text)
        product ={
            '名称':re.findall(re1, response.text),
            '商品ID':re.findall(re2, response.text),
            '类别':re.findall(re16, response.text),
            '邮票网址': url,
            '价格':re.findall(re3, response.text),
            '浏览量':re.findall(re4, response.text),
            '商品单位':re.findall(re5, response.text),
            '全套数': re.findall(re6, response.text),
            '整张数':re.findall(re7, response.text),
            '发行日期':re.findall(re8, response.text),
            '规格':re.findall(re9, response.text),
            '齿孔度数':re.findall(re10, response.text),
            '设计者':re.findall(re11, response.text),
            '版别':re.findall(re12, response.text),
            '印刷厂':re.findall(re13, response.text),
            '邮票介绍':re.findall(re14, response.text),
            '标签':re.findall(re15, response.text),
        }
        print(product)
def get_shop_url():
    """
    1、读取文件
    """
    for id in range(1,3):
        path = 'sp_url'+str(id)+'.csv'
        with open(path, 'r', encoding='utf-8', newline='')as f:
            list1 = []
            for shop_id in f:
                list1.append(shop_id)
            for item in list1[1:]:
                print(item)
            print(list1[0])



def main():
    get_shop_url()


if __name__ == '__main__':
    main()