import csv,codecs
import re
from sphinx.util import requests
from config import *


def get_shop_url():
    """
    1、读取文件
    """
    for id in range(1, 59):
        path = 'sp_url'+str(id)+'.csv'
        with codecs.open(path, 'r', encoding='utf-8-sig')as f:
            list1 = []
            for shop_id in f:
                list1.append(shop_id)
            print(id)
            for item in list1[1:]:
                print(item)
                get_shop_id(item, list1[0])


def get_shop_id(url, classe):
    try:
        url = 'http://www.e1988.com'+str(url).replace('\r\n','')
        response = requests.get(url =url, headers =HEADERS)
        response.encoding ='gbk'
        if response.status_code ==200:
            re1 = re.compile('<li style="width:800px.*?#333;">(.*?)</li>', re.S)
            re2 = re.compile('商品ID：(\d+).*?<a href', re.S)
            re3 = re.compile('YaHei;">(.*?)</b>', re.S)
            re4 = re.compile('浏览量：(\d+)<br />', re.S)
            re5 = re.compile('【商品单位】：(.*?)</li>', re.S)
            re6 = re.compile('【全 套 数】：(.*?)</li>', re.S)
            re7 = re.compile('【整 张 数】：(.*?)</li>', re.S)
            re8 = re.compile('【发行日期】：(.*?)</li>', re.S)
            re9 = re.compile('【 规　格 】：(.*?)</li>', re.S)
            re10 = re.compile('【齿孔度数】：(.*?)</li>', re.S)
            re11 = re.compile('【设 计 者】：(.*?)</li>', re.S)
            re12 = re.compile('【 版　别 】：(.*?)</li>', re.S)
            re13 = re.compile('【印 刷 厂】：(.*?)</li>', re.S)
            re14 = re.compile('<p><STRONG>图案面值:(.*?)<span class=\'AddE1988String\'>', re.S)
            re15 = re.compile('标签：(.*?)</span><br />', re.S)
            re16 = re.compile('【藏品类别】 <A.*?">(.*?)</A>', re.S)
            shop_id = re.findall(re2, response.text)
            product ={
                '名称':re.findall(re1, response.text),
                '商品ID':re.findall(re2, response.text),
                '类别':classe.replace('\r',''),
                '邮票网址': url,
                '价格':re.findall(re3, response.text),
                '浏览量':re.findall(re4, response.text),
                '商品单位':re.findall(re5, response.text),
                '全套数': re.findall(re6, response.text),
                '整张数':re.findall(re7, response.text),
                '发行日期':re.findall(re8, response.text),
                '规格':re.findall(re9, response.text),
                '齿孔度数':re.findall(re10, response.text),
                '设计者':re.findall(re11, response.text),
                '版别':re.findall(re12, response.text),
                '印刷厂':re.findall(re13, response.text),
                '邮票介绍':re.findall(re14, response.text),
                '标签':re.findall(re15, response.text),
            }
        #print(product)
            get_comments(''.join(shop_id),1)
            save_csv(product)
    except:
        print('跳过一家')


def get_comments(shop_id,page):
    try:
        url = 'http://www.e1988.com/merchandisereview/index.asp?id='+str(shop_id)+'&page='+str(page)
        response = requests.get(url=url, headers=HEADERS)
        response.encoding = 'gbk'
        if response.status_code == 200:
            re1 = re.compile('&page=(\d+)\'>\d+</a>')
            re2 = re.compile('<li class="jj_ul1_li2">(.*?)<br />', re.S)
            re3 = re.compile('<br /><b>(.*?)</b></li>', re.S)
            re4 = re.compile('jj_ul2_li1" title="(.*?)">', re.S)
            re5 = re.compile('"jj_ul2_li2">(.*?)</li></ul>', re.S)
            mapge = re.findall(re1,response.text)
            if mapge:
                maxpage = max(mapge)
            else:
                maxpage=None
            level = re.findall(re2, response.text)
            name = re.findall(re3, response.text)
            shop_name = re.findall(re4, response.text)
            comment = re.findall(re5, response.text)
            comments = [[a,b,c,d] for a,b,c,d in zip(level,name,shop_name,comment)]
            for item in comments:
                item.append(str(shop_id))
                with codecs.open('sp_comments.csv', 'w', encoding='utf-8-sig') as f:
                    writer = csv.writer(f)
                    writer.writerow(item)
            page+=1
            if maxpage:
                if page<=int(maxpage):
                    get_comments(shop_id,page)
    except:
        print('跳过一次评论')


def save_csv(product):
    li = []
    for value in product.values():
        if value:
            values = (''.join(value)).replace('\n','')
            li.append(values)
        else:
            li.append('NULL')
    with codecs.open('sp_stamp_result.csv', 'a', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        #filedname = product.keys()
        #writer.writerow(filedname)
        writer.writerow(li)


def main():
    get_shop_url()

if __name__ == '__main__':
    main()