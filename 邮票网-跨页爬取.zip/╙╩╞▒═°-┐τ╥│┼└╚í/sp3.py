import csv,codecs
import re
from sphinx.util import requests
from config import *



def get_comments(shop_id,page):
    url = 'http://www.e1988.com/merchandisereview/index.asp?id='+str(shop_id)+'&page='+str(page)
    response = requests.get(url=url, headers=HEADERS)
    response.encoding = 'gbk'
    if response.status_code == 200:
        re1 = re.compile('&page=(\d+)\'>\d+</a>')
        re2 = re.compile('<li class="jj_ul1_li2">(.*?)<br />', re.S)
        re3 = re.compile('<br /><b>(.*?)</b></li>', re.S)
        re4 = re.compile('jj_ul2_li1" title="(.*?)">', re.S)
        re5 = re.compile('"jj_ul2_li2">(.*?)</li></ul>', re.S)
        mapge = re.findall(re1,response.text)
        if mapge:
            maxpage = max(mapge)
        else:
            maxpage=None
        level = re.findall(re2, response.text)
        name = re.findall(re3, response.text)
        shop_name = re.findall(re4, response.text)
        comment = re.findall(re5, response.text)
        comments = [[a,b,c,d] for a,b,c,d in zip(level,name,shop_name,comment)]
        with codecs.open('sp_comments.csv', 'a+', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                #head =['level','name','shop_name','comment','num']
                #writer.writerow(head)
                for item in comments:
                    item.append(str(shop_id))
                    print(item)
                    writer.writerow(item)
        page+=1
        if maxpage:
            if page<=int(maxpage):
                get_comments(shop_id,page)


def main():
   get_comments(222,1)


if __name__ == '__main__':
    main()