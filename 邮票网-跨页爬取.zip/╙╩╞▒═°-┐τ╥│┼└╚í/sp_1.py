import csv,codecs
import re
from pyquery import PyQuery as pq
from requests import RequestException
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from sphinx.util import requests
from urllib.parse import urlencode
from config import *
import time


def get_shop_id():
    #url ="http://www.e1988.com/collectionsort-0000.0001.0001.0001.0010.html"
    for j in range(1,2):
        url = 'http://www.e1988.com/collectionsort-0000.0001.0001.0006.0003.html&page='+str(j)
        response = requests.get(url =url, headers =HEADERS)
        response.encoding ='gbk'
        if response.status_code ==200:
            doc =pq(response.text)
            items = doc.items()
            re_1 = re.compile('<div class="sp_div".*?<a href="(.*?)"',re.S)
            url_shop = re.findall(re_1,str(doc))
            print(url_shop)
            for item in items:
                product = {
                    '类别':item.find('.sp_sx1 span').text(),
                    '页数':item.find('.fenye').text()

                }
                print(product)
            for line in url_shop:
                ls = []
                ls.append(line)
                with codecs.open('sp_url58.csv', 'a', encoding='utf-8-sig') as f:
                    writer = csv.writer(f)
                    writer.writerow(ls)


def main():
    get_shop_id()

if __name__ == '__main__':
    main()